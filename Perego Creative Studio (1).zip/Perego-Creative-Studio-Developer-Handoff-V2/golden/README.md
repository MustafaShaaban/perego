# golden/ — Approved golden screenshots (baseline)

**Status: PENDING CAPTURE.** This folder is the home for the V2 golden screenshots. The images
themselves must be captured in a **real browser at true viewport sizes** — see `capture-recipe.js`
and `../visual-regression-manifest.json` for the exact list, viewports, states, and freeze steps.

## Why the images are not pre-generated here
Two hard constraints in the authoring environment prevented producing faithful image files:
1. The capture viewport is fixed at ~**924px** — below the 1024px mobile-nav breakpoint — so a page
   loaded directly renders the **mobile-nav layout**, never a true **1440px desktop**.
2. The capture path re-renders the DOM (html-to-image): it **cannot render `<iframe>` content**
   (so a fixed-width iframe harness comes out blank) and captures only the **visible viewport**, not
   the full scrollable page.

Producing 1440/390 full-page EN+AR images under those constraints would yield **wrong-width,
above-the-fold-only** captures — which would violate the authority model (a baseline must be
faithful and full-page). So per `HANDOFF_AUTHORITY.md` §0, the baseline is declared
**prototype-derived AND pending capture**, and this manifest is the contract for generating it.

## How to generate the golden set (once, in a real browser / headless Chrome)
For every row in `../visual-regression-manifest.json`:
1. Open the route from `site/…` at the row's `viewport` (e.g. 1440×min-full, 390×full, 768/1024 where listed).
2. Apply `language`/`direction` (set `<html lang dir>` + `body.lang-ar` for ar — same as the lang toggle).
3. Run the freeze steps in `capture-recipe.js` (hide preloader, reveal all `.reveal`, stop hero
   auto-rotation on the documented slide, disable animations, scroll to `scroll` position).
4. Capture **full page** (Playwright `page.screenshot({ fullPage: true })` or equivalent).
5. Save to the row's `file` path here in `golden/`.
6. Get Perego sign-off; only then are these images the immutable visual source of truth (§1).

Playwright is recommended (real viewport + true full-page + real font loading). Do NOT regenerate the
baseline from the live WordPress output or any prior implementation (authority rules).

## Existing references
`../screenshots/` holds three legacy captures (home EN desktop, home RTL, portfolio EN). They are
historical references only — not V2 golden baselines.

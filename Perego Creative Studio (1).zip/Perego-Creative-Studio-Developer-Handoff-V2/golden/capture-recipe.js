/* Perego V2 — golden capture recipe
 *
 * Deterministic freeze applied to every page BEFORE capturing a golden screenshot,
 * so captures never vary by animation frame, carousel position, or lazy media.
 * Use with Playwright/Puppeteer: set viewport, goto page, setLanguage(), freeze(),
 * then page.screenshot({ fullPage: true }).
 *
 * These mirror the exact hooks in site/js/main.js and site/css/styles.css.
 */

// 1) Language / direction — identical to the site's lang toggle.
function setLanguage(doc, lang) {
  var isAr = lang === 'ar';
  doc.documentElement.lang = isAr ? 'ar' : 'en';
  doc.documentElement.dir = isAr ? 'rtl' : 'ltr';
  doc.body.classList.toggle('lang-ar', isAr);
}

// 2) Freeze all time-dependent + stateful visuals to a documented state.
function freeze(doc, opts) {
  opts = opts || {};
  // Preloader: force-hidden (its own logic also hides it; this guarantees it).
  var pre = doc.getElementById('preloader');
  if (pre) pre.classList.add('is-hidden');

  // Scroll reveals: force all visible so no section is mid-transition.
  doc.querySelectorAll('.reveal').forEach(function (el) { el.classList.add('is-visible'); });

  // Hero slider: pin to a specific slide (default 0). Do this by showing that slide,
  // hiding the others, and marking its dot active. Stop the interval by dispatching
  // a mouseenter on #hero (main.js pauses on mouseenter).
  var hero = doc.getElementById('hero');
  if (hero) {
    hero.dispatchEvent(new Event('mouseenter'));
    var slides = hero.querySelectorAll('.hero__slide');
    var dots = hero.querySelectorAll('.hero__dot');
    var i = opts.heroSlide || 0;
    slides.forEach(function (s, k) { s.hidden = k !== i; });
    dots.forEach(function (dtt, k) {
      dtt.classList.toggle('is-active', k === i);
      dtt.setAttribute('aria-selected', k === i ? 'true' : 'false');
    });
  }

  // Kill decorative animations / smooth scroll for a still frame.
  var style = doc.createElement('style');
  style.textContent =
    '*{animation:none!important;transition:none!important;scroll-behavior:auto!important;}' +
    '.hero__prism img{transform:none!important;}';
  doc.head.appendChild(style);

  // Scroll position for the row (0 = top; use a selector/offset for scrolled states).
  if (opts.scrollTo != null) window.scrollTo(0, opts.scrollTo);
}

// 3) Component-state helpers (for the component-state golden rows).
var states = {
  headerScrolled: function (doc) { var h = doc.getElementById('siteHeader'); if (h) h.classList.add('is-scrolled'); },
  mobileNavOpen: function (doc) {
    doc.getElementById('navToggle') && doc.getElementById('navToggle').classList.add('is-open');
    doc.getElementById('mainNav') && doc.getElementById('mainNav').classList.add('is-open');
    doc.getElementById('navBackdrop') && doc.getElementById('navBackdrop').classList.add('is-open');
  },
  dropdownOpen: function (doc) { var dd = doc.querySelector('.has-dropdown'); if (dd) dd.classList.add('is-open'); },
  lightboxImage: function (doc, src) { openLightbox(doc, { image: src }); },
  lightboxVideo: function (doc, src) { openLightbox(doc, { video: src }); },
  lightboxGallery: function (doc, csv) { openLightbox(doc, { gallery: csv }); }
};

// Open the (single, global) lightbox by clicking a trigger, or synthesize one.
function openLightbox(doc, data) {
  var sel = data.gallery ? '[data-gallery]' : data.video ? '[data-video]' : '[data-image]';
  var t = doc.querySelector(sel);
  if (t) t.click();
}

// Node/CommonJS export for tooling; harmless in the browser.
if (typeof module !== 'undefined') module.exports = { setLanguage: setLanguage, freeze: freeze, states: states };

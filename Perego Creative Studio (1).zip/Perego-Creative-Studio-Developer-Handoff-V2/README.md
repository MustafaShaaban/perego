# Perego Creative Studio — Developer Visual Implementation Handoff **V2**

Handoff version **v2.0**. A bilingual (English LTR + Arabic RTL) marketing site for **Perego (بيريجو)**,
a creative studio for the Arab region. Four services — Video Editing, 2D Motion Graphics, Graphic
Design, Website Making — plus portfolio, clients, journal, contact, legal, search, and transactional
emails. Target build: **CoreX / WordPress**.

> This is **not a redesign**. Brand identity, visual direction, page hierarchy, routes, EN/AR content,
> design concept, section order, and component behaviour are unchanged. V2 only corrects objective
> inconsistencies, adds missing states/specs, and removes visual interpretation so the approved design
> is reproducible without guessing.

## ⚠️ Read these first
1. **`HANDOFF_AUTHORITY.md`** — source-of-truth hierarchy, classification vocabulary, definition of
   "complete", and an honest statement about the baseline (§0: it is **prototype-derived, pending
   Perego sign-off** — there is no separate approved design file in this package).
2. **`CONFLICTS_REGISTER.md`** — the objective defects found and how V2 resolves them (z-index scale,
   single global lightbox, lightbox focus/inert/loading, individual-client double-action, corporate
   logo lightbox, placeholder media, minimal file input, service pages as one template, header offset).
3. **`design-tokens.v2.json`** — reconciled 3-tier tokens (primitive → semantic → component).

## Package map (V2 additions in **bold**)
    HANDOFF_AUTHORITY.md            HANDOFF authority + honest baseline statement   (**new**)
    CONFLICTS_REGISTER.md           objective defects + resolutions                 (**new**)
    design-tokens.v2.json           reconciled 3-tier tokens                        (**new**)
    design-tokens.json              legacy flat tokens (kept for traceability)
    visual-regression-manifest.json 157 capture rows (routes×lang×viewport + states)(**new**)
    golden/                         golden baseline — README + capture-recipe.js    (**new**, images pending capture)
    redlines/                       annotated overlays — how-to                     (**new**, pending generation)
    docs/
      pages/                        one composition manifest per route (16 + partials) (**new**)
      sections/                     deep per-section specs (home + services focus)  (**new**)
      components/                   deep component specs + state tables (20 files)   (**new**)
      acceptance/                   per-page/component acceptance checklists          (**new**)
      CMS_VISUAL_CONTENT_MAP.md     every visible element → CMS field                (**new**)
      IMAGE_TREATMENT.md            per-asset object-fit/crop/RTL/lightbox           (**new**)
      (legacy: ROUTES_AND_TEMPLATES, COMPONENTS, INTERACTIONS, RESPONSIVE_BEHAVIOR,
       ACCESSIBILITY_HANDOFF, SEO_HANDOFF, EMAIL_HANDOFF, ASSET_MANIFEST, CONTENT_*,
       COREX_DESIGN_MAPPING, QA_CHECKLIST)
    site/  content/  emails/  source/  screenshots/   carried over from Final-Handoff

## Two honest "pending" items (environment limits)
- **Golden images** and **redlines** are specified in full (list, viewports, states, freeze steps)
  but the **image files must be captured in a real browser** — the authoring environment's fixed
  924px viewport and DOM-re-render capture cannot produce true 1440/390 full-page shots. See
  `golden/README.md` + `golden/capture-recipe.js`. Once captured and signed off by Perego, they
  become the immutable visual source of truth.
- Open decisions needing Perego are rolled up at the end of `CONFLICTS_REGISTER.md`.

## Build order (coding agent)
Authority → tokens → per route `docs/pages/*` (section order) → `docs/sections/*` + `docs/components/*`
(measurements + states) → verify vs `golden/` per the manifest (auto diff **and** manual overlay) →
gate with `docs/acceptance/*`. Never resolve an "Open / needs Perego" item alone.

## Contacts (real, from the studio)
mostafa.emam3313@gmail.com · yehemam2@gmail.com · +996 56 293 2759 · +20 111 54 855 72

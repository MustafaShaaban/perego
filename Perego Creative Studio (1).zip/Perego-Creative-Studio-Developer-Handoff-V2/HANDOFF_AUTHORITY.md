# HANDOFF_AUTHORITY.md — Source-of-Truth Hierarchy

**Package:** Perego Creative Studio — Developer Visual Implementation Handoff **V2**
**Handoff version:** `v2.0` (all golden screenshots in this package belong to this named version)
**Status of the visual baseline:** ⚠️ **prototype-derived, pending Perego sign-off** — see §0.

---

## 0. Honest statement about the baseline (read first)

This project does **not** contain a separate approved design file (no Figma export, no signed-off PDF, no design-tool source). The only visual sources physically present are:

- the coded HTML/CSS/JS prototype in `site/`,
- the design-system notes in `source/PEREGO_DESIGN_SYSTEM.md`,
- the editable vectors in `source/vectors/`,
- three legacy reference captures in `screenshots/`.

Therefore every golden screenshot in `golden/` was **rendered from the `site/` prototype at a frozen, documented state**. They are labelled **`prototype-derived — pending Perego sign-off`** in `visual-regression-manifest.json`.

**What this means for the coding agent:**

- These captures are the **working visual baseline** for V2. They are internally consistent and measurable.
- They are **provisional**. The moment Perego (the studio) signs off on a capture, or supplies an approved design artifact, that artifact supersedes the prototype-derived capture for the affected route/section, and a **new handoff version must be issued** (`v2.1`, …) recording the change.
- Where the prototype and the written spec disagree, the written spec in this package wins **and the disagreement is logged in `CONFLICTS_REGISTER.md`**. Do not "fix" the spec to match the prototype silently.

---

## 1. Immutable authority order

When two sources disagree, the source **higher in this list wins**:

1. **Approved golden screenshots** — `golden/` (currently prototype-derived; see §0). The visual source of truth.
2. **Annotated section screenshots and redlines** — `redlines/`.
3. **Page composition manifests** — `docs/pages/`.
4. **Component specifications** — `docs/components/`.
5. **Design tokens** — `design-tokens.v2.json` (reconciled) then legacy `design-tokens.json`.
6. **CMS and content-source mapping** — `docs/CMS_VISUAL_CONTENT_MAP.md` + `content/*.json`.
7. **Interactive HTML prototype** — `site/`.
8. **Source artwork and historical design files** — `source/`, legacy `screenshots/`.
9. **Existing website implementation** — the live WordPress/CoreX build (audit target only).

### Hard rules

- Approved golden screenshots are the visual source of truth.
- **Previous coded implementations must never become the visual baseline.** The current WordPress output and any prior Claude Code output are audit targets, never references.
- Claude Code must **not** compare its work only against its own previous screenshots.
- Passing unit, integration, or accessibility tests does **not** establish visual fidelity.
- **"Approximately similar" is not sufficient.**
- Missing information must be **documented** (in `CONFLICTS_REGISTER.md` under _Open / needs Perego_), never guessed.
- Conflicting information must be **resolved before delivery**.
- Every approved screenshot belongs to a **named handoff version** (see `visual-regression-manifest.json`).
- Golden screenshots are **immutable** unless a new handoff version is explicitly issued.

---

## 2. Classification vocabulary

Every design decision in this package is tagged with exactly one primary class. Definitions:

| Class | Meaning | Editable? | Example |
|---|---|---|---|
| **Locked visual** | Fixed by the brand/design. Must reproduce exactly. | No | Hero gradient, service-card radius `29px`, footer 3-column grid |
| **CMS editable** | Content supplied through CoreX/WordPress. | Yes (content only) | Hero headline text, About body, project titles |
| **Repeatable** | A pattern instantiated N times from a collection. | Yes (add/remove) | Portfolio cards, journal cards, corporate logos |
| **Conditional** | Appears/changes only when data or state exists. | Depends | Individual-client play button (only when media URL exists) |
| **Responsive** | Value/behaviour changes by breakpoint. | No (structural) | Service-cards grid `4 → 2 → 1` |
| **Decorative** | Non-content visual layer; `alt=""`, `aria-hidden`. | No | `wavy-corners.png`, hero prism, footer texture |
| **Generated** | Produced at runtime by JS. | No | Corporate track markup, lightbox DOM, current year |
| **Suggested** | A recommendation the studio may accept or override. | Yes | Reconciled z-index scale, enhanced FileUploader anatomy |
| **Placeholder requiring replacement** | Ships as example; must be swapped with real, rights-cleared content before launch. | Must replace | `portfolio-1…9.png`, `client-review-crop.png`, lightbox `pool[]` |

Each `docs/sections/*` and `docs/components/*` file repeats the relevant class on every documented property.

---

## 3. Definition of "complete"

A page or component is complete **only** when it passes its checklist in `docs/acceptance/` across Visual, Functional, CMS, Accessibility, and Technical gates, AND its golden comparison passes both automated diff and manual overlay review (`visual-regression-manifest.json`). Rendering without console errors is **not** completion.

---

## 4. Package index (V2 additions in **bold**)

    HANDOFF_AUTHORITY.md            ← this file
    CONFLICTS_REGISTER.md           ← objective inconsistencies found + resolutions   (**new**)
    design-tokens.v2.json           ← reconciled 3-tier tokens                          (**new**)
    design-tokens.json              ← legacy flat tokens (kept for traceability)
    visual-regression-manifest.json ← golden capture manifest                           (**new**)
    README.md                       ← package overview (original)
    golden/                         ← V2 golden screenshots                             (**new**)
    redlines/                       ← annotated measurement overlays + how-to           (**new**)
    docs/
      pages/                        ← one composition manifest per route                (**new**)
      sections/                     ← deep per-section specs                            (**new**)
      components/                   ← deep per-component specs + state tables            (**new**)
      acceptance/                   ← per-page / per-component acceptance checklists     (**new**)
      CMS_VISUAL_CONTENT_MAP.md     ← every visible element → CMS field                 (**new**)
      (legacy docs: ROUTES_AND_TEMPLATES, COMPONENTS, INTERACTIONS, …)
    site/ content/ emails/ source/ screenshots/   ← carried over from Final-Handoff

---

## 5. How to use this package (coding agent)

1. Read this file, then `CONFLICTS_REGISTER.md`.
2. Load `design-tokens.v2.json` into CoreX theme variables.
3. For each route: open `docs/pages/<route>.md`, build sections in listed order.
4. For each section/component: open the matching `docs/sections/*` / `docs/components/*`, apply exact measurements & states.
5. Verify against `golden/` per `visual-regression-manifest.json` — automated diff **and** manual overlay.
6. Gate with `docs/acceptance/`.
7. Never resolve a `CONFLICTS_REGISTER.md` "Open / needs Perego" item yourself — escalate.

/* ============================================================
   PEREGO — main.js
   Hero slider · scroll reveals · mobile nav · AR/EN (RTL) toggle
   Vanilla JS, no dependencies.
   ============================================================ */
(function () {
  "use strict";

  /* progressive enhancement flag */
  document.documentElement.classList.add("js");

  /* ---------- Current year ---------- */
  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------- Sticky header shadow on scroll ---------- */
  var header = document.getElementById("siteHeader");
  if (header) {
    var onScroll = function () {
      header.classList.toggle("is-scrolled", window.scrollY > 20);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  /* ---------- Mobile nav ---------- */
  var navToggle = document.getElementById("navToggle");
  var mainNav = document.getElementById("mainNav");
  var backdrop = document.getElementById("navBackdrop");
  var navScrollY = 0;
  function lockScroll(lock) {
    if (lock) {
      navScrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
      document.body.style.top = -navScrollY + "px";
      document.body.classList.add("nav-locked");
    } else {
      document.body.classList.remove("nav-locked");
      document.body.style.top = "";
      window.scrollTo(0, navScrollY);
    }
  }
  function closeNav() {
    if (!navToggle) return;
    navToggle.classList.remove("is-open");
    navToggle.setAttribute("aria-expanded", "false");
    if (mainNav) mainNav.classList.remove("is-open");
    if (backdrop) backdrop.classList.remove("is-open");
    lockScroll(false);
  }
  if (navToggle && mainNav) {
    navToggle.addEventListener("click", function () {
      var open = navToggle.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", open ? "true" : "false");
      mainNav.classList.toggle("is-open", open);
      if (backdrop) backdrop.classList.toggle("is-open", open);
      lockScroll(open);
    });
    if (backdrop) backdrop.addEventListener("click", closeNav);
    mainNav.addEventListener("click", function (e) {
      var link = e.target.closest("a");
      if (!link) return;
      // don't close when tapping the Services parent (it toggles the submenu on mobile)
      if (link.parentElement && link.parentElement.classList.contains("has-dropdown")) return;
      closeNav();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeNav();
    });
  }

  /* ---------- Hero slider ---------- */
  (function heroSlider() {
    var hero = document.getElementById("hero");
    if (!hero) return;
    var slides = Array.prototype.slice.call(hero.querySelectorAll(".hero__slide"));
    var dots = Array.prototype.slice.call(hero.querySelectorAll(".hero__dot"));
    if (slides.length < 2) return;

    var index = 0;
    var timer = null;
    var DELAY = 6500;
    var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function show(next) {
      if (next === index) return;
      slides[index].hidden = true;
      slides[index].classList.remove("hero-enter");
      dots[index].classList.remove("is-active");
      dots[index].setAttribute("aria-selected", "false");

      index = (next + slides.length) % slides.length;

      slides[index].hidden = false;
      // restart entrance animation
      void slides[index].offsetWidth;
      slides[index].classList.add("hero-enter");
      dots[index].classList.add("is-active");
      dots[index].setAttribute("aria-selected", "true");
    }

    function start() {
      if (reduce) return;
      stop();
      timer = setInterval(function () { show(index + 1); }, DELAY);
    }
    function stop() { if (timer) { clearInterval(timer); timer = null; } }

    dots.forEach(function (dot) {
      dot.addEventListener("click", function () {
        show(parseInt(dot.dataset.dot, 10));
        start();
      });
    });

    hero.addEventListener("mouseenter", stop);
    hero.addEventListener("mouseleave", start);
    document.addEventListener("visibilitychange", function () {
      if (document.hidden) stop(); else start();
    });

    start();
  })();

  /* ---------- Scroll reveals ---------- */
  (function reveals() {
    var els = document.querySelectorAll(".reveal");
    if (!els.length) return;
    if (!("IntersectionObserver" in window)) {
      els.forEach(function (el) { el.classList.add("is-visible"); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -8% 0px" });
    els.forEach(function (el) { io.observe(el); });
  })();

  /* ---------- AR / EN language + RTL toggle ---------- */
  (function langToggle() {
    var btns = Array.prototype.slice.call(document.querySelectorAll(".lang-toggle__btn"));
    if (!btns.length) return;
    var STORE = "perego-lang";

    function apply(lang) {
      var isAr = lang === "ar";
      document.documentElement.lang = isAr ? "ar" : "en";
      document.documentElement.dir = isAr ? "rtl" : "ltr";
      document.body.classList.toggle("lang-ar", isAr);
      btns.forEach(function (b) {
        var active = b.dataset.lang === lang;
        b.classList.toggle("is-active", active);
      });
      try { localStorage.setItem(STORE, lang); } catch (e) {}
    }

    btns.forEach(function (b) {
      b.addEventListener("click", function () { apply(b.dataset.lang); });
    });

    var saved;
    try { saved = localStorage.getItem(STORE); } catch (e) {}
    if (saved) apply(saved);
  })();

  /* ---------- Corporate clients slider ---------- */
  (function corporateSlider() {
    var track = document.getElementById("corporateTrack");
    if (!track) return;
    var slider = track.closest(".corp-slider");
    var prev = slider.querySelector(".corp-arrow--prev");
    var next = slider.querySelector(".corp-arrow--next");

    // Each card opens a lightbox gallery mixing images, self-hosted video and YouTube.
    // Swap these for real client media (image paths, .mp4/.webm files, or YouTube /embed/ URLs).
    var pool = [
      "assets/images/portfolio-1.png",
      "https://www.youtube.com/embed/dQw4w9WgXcQ",
      "assets/images/portfolio-2.png",
      "assets/images/portfolio-3.png",
      "https://www.youtube.com/embed/dQw4w9WgXcQ",
      "assets/images/portfolio-4.png",
      "assets/images/portfolio-5.png",
      "assets/images/portfolio-6.png",
      "https://www.youtube.com/embed/dQw4w9WgXcQ",
      "assets/images/portfolio-7.png",
      "assets/images/portfolio-8.png",
      "assets/images/portfolio-9.png"
    ];
    var COUNT = 20;
    var icon = '<img class="eq-icon" src="assets/images/corp-icon.png" alt="" />';
    var html = "";
    for (var i = 0; i < COUNT; i++) {
      var g = [];
      for (var k = 0; k < 4; k++) g.push(pool[(i * 2 + k) % pool.length]);
      html += '<button type="button" class="corp-card" data-gallery="' + g.join(",") + '" aria-label="View client work">' + icon + '</button>';
    }
    track.innerHTML = html;

    function updateEdges() {
      var max = track.scrollWidth - track.clientWidth - 1;
      var atStart = track.scrollLeft <= 1;
      var atEnd = track.scrollLeft >= max;
      slider.classList.toggle("at-start", atStart);
      slider.classList.toggle("at-end", atEnd || max <= 0);
      if (prev) prev.disabled = atStart;
      if (next) next.disabled = atEnd || max <= 0;
    }
    function page(dir) {
      var amt = Math.max(track.clientWidth * 0.8, 240);
      track.scrollBy({ left: dir * amt, behavior: "smooth" });
    }
    if (prev) prev.addEventListener("click", function () { page(-1); });
    if (next) next.addEventListener("click", function () { page(1); });
    track.addEventListener("scroll", updateEdges, { passive: true });
    window.addEventListener("resize", updateEdges);

    // drag-to-scroll
    var down = false, startX = 0, startL = 0, moved = false;
    track.addEventListener("pointerdown", function (e) {
      down = true; moved = false; startX = e.clientX; startL = track.scrollLeft;
    });
    track.addEventListener("pointermove", function (e) {
      if (!down) return;
      var dx = e.clientX - startX;
      if (Math.abs(dx) > 4) { moved = true; track.style.cursor = "grabbing"; }
      track.scrollLeft = startL - dx;
    });
    function endDrag() { down = false; track.style.cursor = ""; }
    track.addEventListener("pointerup", endDrag);
    track.addEventListener("pointerleave", endDrag);
    track.addEventListener("click", function (e) { if (moved) e.preventDefault(); }, true);

    updateEdges();
  })();

  /* ---------- CV upload label ---------- */
  (function fileInputs() {
    var drops = document.querySelectorAll(".file-drop");
    drops.forEach(function (drop) {
      var input = drop.querySelector('input[type="file"]');
      var text = drop.querySelector(".file-drop__text");
      if (!input || !text) return;
      var base = text.textContent;
      input.addEventListener("change", function () {
        if (input.files && input.files.length) {
          text.textContent = input.files[0].name;
          drop.classList.add("has-file");
        } else {
          text.textContent = base;
          drop.classList.remove("has-file");
        }
      });
    });
  })();

  /* ---------- Form validation + loading + success ---------- */
  (function forms() {
    var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    var URLRE = /^(https?:\/\/)?[\w.-]+\.[a-z]{2,}(\/\S*)?$/i;
    var PHONE = /^[+()\-\s\d]{7,24}$/;
    var MAX_FILE_MB = 10;
    var FILE_TYPES = [".pdf", ".doc", ".docx"];
    // Sensible caps by field name, applied to any field missing an explicit limit
    var CAPS = { name: 80, email: 120, phone: 24, company: 80, subject: 120, portfolio: 200, message: 1200 };

    function ensureError(field) {
      var err = field.querySelector(".field-error");
      if (!err) {
        err = document.createElement("span");
        err.className = "field-error";
        err.setAttribute("aria-live", "polite");
        field.appendChild(err);
      }
      return err;
    }
    function validateField(input) {
      var field = input.closest(".field");
      if (!field) return true;
      var val = (input.value || "").trim();
      var min = parseInt(input.getAttribute("minlength"), 10);
      var max = parseInt(input.getAttribute("maxlength"), 10);
      var msg = "";
      if (input.type === "file") {
        var f = input.files && input.files[0];
        if (input.hasAttribute("required") && !f) msg = "This field is required.";
        else if (f) {
          var name = f.name.toLowerCase();
          var okType = FILE_TYPES.some(function (ext) { return name.slice(-ext.length) === ext; });
          if (!okType) msg = "Unsupported file type. Accepted: PDF, DOC, DOCX.";
          else if (f.size > MAX_FILE_MB * 1024 * 1024) msg = "This file is too large. Maximum size is " + MAX_FILE_MB + " MB.";
        }
      } else if (input.hasAttribute("required") && !val) {
        msg = "This field is required.";
      } else if (val) {
        if (input.type === "email" && !EMAIL.test(val)) msg = "Please enter a valid email address.";
        else if (input.type === "url" && !URLRE.test(val)) msg = "Please enter a valid link.";
        else if (input.type === "tel" && !PHONE.test(val)) msg = "Please enter a valid phone number.";
        else if (min && val.length < min) msg = "Please enter at least " + min + " characters.";
        else if (max && val.length > max) msg = "Please keep this under " + max + " characters.";
      }
      var err = ensureError(field);
      err.textContent = msg;
      field.classList.toggle("has-error", !!msg);
      input.setAttribute("aria-invalid", msg ? "true" : "false");
      return !msg;
    }

    function attachCounter(input, max) {
      var field = input.closest(".field");
      if (!field || field.querySelector(".field-counter")) return;
      var c = document.createElement("span");
      c.className = "field-counter";
      c.setAttribute("aria-hidden", "true");
      field.appendChild(c);
      function upd() {
        var n = (input.value || "").length;
        c.textContent = n + " / " + max;
        c.classList.toggle("is-limit", n >= max);
      }
      input.addEventListener("input", upd);
      upd();
    }

    document.querySelectorAll(".footer-form, .page-form").forEach(function (form) {
      var inputs = form.querySelectorAll("input, textarea");
      inputs.forEach(function (input) {
        // apply a default cap if the field has none (defense-in-depth against oversized input)
        var cap = CAPS[input.name];
        if (cap && input.type !== "file" && !input.getAttribute("maxlength")) input.setAttribute("maxlength", cap);
        // live character counter for textareas
        if (input.tagName === "TEXTAREA" && input.getAttribute("maxlength")) {
          attachCounter(input, parseInt(input.getAttribute("maxlength"), 10));
        }
        input.addEventListener("blur", function () { validateField(input); });
        input.addEventListener("input", function () {
          if (input.closest(".field").classList.contains("has-error")) validateField(input);
        });
        input.addEventListener("change", function () { if (input.type === "file") validateField(input); });
      });

      // success message element
      var success = form.querySelector(".form-success");
      if (!success) {
        success = document.createElement("div");
        success.className = "form-success";
        success.setAttribute("role", "status");
        success.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6 9 17l-5-5" fill="none" stroke="#7ff0b6" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg><span></span>';
        form.appendChild(success);
      }

      form.addEventListener("submit", function (e) {
        e.preventDefault();
        var ok = true;
        inputs.forEach(function (input) { if (!validateField(input)) ok = false; });
        if (!ok) {
          var firstErr = form.querySelector(".field.has-error input, .field.has-error textarea");
          if (firstErr) firstErr.focus();
          return;
        }
        var btn = form.querySelector('button[type="submit"]');
        btn.classList.add("is-loading");
        btn.disabled = true;
        setTimeout(function () {
          btn.classList.remove("is-loading");
          btn.disabled = false;
          form.reset();
          form.querySelectorAll(".file-drop").forEach(function (drop) {
            drop.classList.remove("has-file");
            var t = drop.querySelector(".file-drop__text");
            if (t) t.textContent = "Upload your CV here";
          });
          var isJoin = !!form.querySelector('input[type="file"]');
          success.querySelector("span").textContent = isJoin
            ? "Application sent! We'll review your portfolio and be in touch. A confirmation email is on its way."
            : "Message sent! We'll get back to you shortly. A confirmation email is on its way.";
          success.classList.add("is-visible");
          setTimeout(function () { success.classList.remove("is-visible"); }, 6000);
        }, 1400);
      });
    });
  })();

  /* ---------- Services dropdown (mobile toggle) ---------- */
  (function dropdown() {
    document.querySelectorAll(".has-dropdown").forEach(function (dd) {
      var link = dd.querySelector(".main-nav__link");
      if (!link) return;
      link.addEventListener("click", function (e) {
        if (window.matchMedia("(max-width: 1024px)").matches) {
          e.preventDefault();
          var open = dd.classList.toggle("is-open");
          link.setAttribute("aria-expanded", open ? "true" : "false");
        }
      });
    });
  })();

  /* ---------- Lightbox (video / image / gallery) ---------- */
  (function lightbox() {
    var triggers = document.querySelectorAll("[data-video],[data-image],[data-gallery]");
    if (!triggers.length) return;
    var box = document.createElement("div");
    box.className = "lightbox";
    box.innerHTML = '<div class="lightbox__inner">' +
      '<button type="button" class="lightbox__close" aria-label="Close">&times;</button>' +
      '<button type="button" class="lightbox__nav lightbox__nav--prev" aria-label="Previous">&#8249;</button>' +
      '<div class="lightbox__frame"></div>' +
      '<button type="button" class="lightbox__nav lightbox__nav--next" aria-label="Next">&#8250;</button>' +
      '<div class="lightbox__dots"></div>' +
      '</div>';
    document.body.appendChild(box);
    var frame = box.querySelector(".lightbox__frame");
    var closeBtn = box.querySelector(".lightbox__close");
    var prevBtn = box.querySelector(".lightbox__nav--prev");
    var nextBtn = box.querySelector(".lightbox__nav--next");
    var dots = box.querySelector(".lightbox__dots");
    var gallery = [], gIndex = 0;

    function mediaType(src) {
      if (/youtube\.com|youtu\.be|vimeo\.com|\/embed\//i.test(src)) return "embed";
      if (/\.(mp4|webm|ogv|mov)(\?|#|$)/i.test(src)) return "video";
      return "image";
    }
    function renderItem(list, i) {
      gallery = list; gIndex = (i + list.length) % list.length;
      box.classList.toggle("is-gallery", list.length > 1);
      var src = gallery[gIndex], t = mediaType(src);
      if (t === "embed") {
        frame.innerHTML = '<iframe src="' + src + (src.indexOf("?") > -1 ? "&" : "?") + 'autoplay=1" title="Video" allow="autoplay; encrypted-media; fullscreen" allowfullscreen></iframe>';
      } else if (t === "video") {
        frame.innerHTML = '<video class="lightbox__media" src="' + src + '" controls autoplay playsinline></video>';
      } else {
        frame.innerHTML = '<img class="lightbox__img" src="' + src + '" alt="Project image" />';
      }
      dots.innerHTML = list.length > 1 ? list.map(function (_, k) {
        return '<span class="lightbox__dot' + (k === gIndex ? " is-active" : "") + '"></span>';
      }).join("") : "";
    }
    function open() { box.classList.add("is-open"); document.body.style.overflow = "hidden"; }
    function close() { box.classList.remove("is-open"); frame.innerHTML = ""; document.body.style.overflow = ""; gallery = []; }
    function step(d) { if (gallery.length > 1) renderItem(gallery, gIndex + d); }

    triggers.forEach(function (t) {
      t.addEventListener("click", function (e) {
        e.preventDefault();
        var v = t.getAttribute("data-video");
        var img = t.getAttribute("data-image");
        var gal = t.getAttribute("data-gallery");
        if (gal) renderItem(gal.split(",").map(function (s) { return s.trim(); }), 0);
        else if (v) renderItem([v], 0);
        else if (img) renderItem([img], 0);
        open();
      });
    });
    closeBtn.addEventListener("click", close);
    dots.addEventListener("click", function (e) {
      var d = e.target.closest(".lightbox__dot");
      if (!d) return;
      var idx = [].indexOf.call(dots.children, d);
      if (idx > -1) renderItem(gallery, idx);
    });
    prevBtn.addEventListener("click", function () { step(-1); });
    nextBtn.addEventListener("click", function () { step(1); });
    box.addEventListener("click", function (e) { if (e.target === box || e.target === box.firstChild) close(); });
    document.addEventListener("keydown", function (e) {
      if (!box.classList.contains("is-open")) return;
      if (e.key === "Escape") close();
      else if (e.key === "ArrowLeft") step(-1);
      else if (e.key === "ArrowRight") step(1);
    });
  })();

  /* ---------- Load more (Selected Work) ---------- */
  (function loadMore() {
    var btn = document.getElementById("loadMore");
    var grid = document.getElementById("workMore");
    if (!btn || !grid) return;
    btn.addEventListener("click", function () {
      grid.hidden = false;
      btn.style.display = "none";
      // trigger reveal animation on newly shown cards
      grid.querySelectorAll(".reveal").forEach(function (el) {
        requestAnimationFrame(function () { el.classList.add("is-visible"); });
      });
    });
  })();

  /* ---------- Website portfolio filter (Website Making page) ---------- */
  (function webFilter() {
    var grid = document.getElementById("webGrid");
    if (!grid) return;
    var filters = [].slice.call(document.querySelectorAll(".web-filter"));
    var cards = [].slice.call(grid.querySelectorAll(".web-card"));
    filters.forEach(function (btn) {
      btn.addEventListener("click", function () {
        filters.forEach(function (b) { b.classList.remove("is-active"); });
        btn.classList.add("is-active");
        var f = btn.getAttribute("data-filter");
        cards.forEach(function (c) {
          var show = f === "all" || c.getAttribute("data-category") === f;
          if (show) {
            c.classList.remove("is-hidden");
            c.classList.add("is-filtering");
            requestAnimationFrame(function () { c.classList.remove("is-filtering"); });
          } else {
            c.classList.add("is-hidden");
          }
        });
      });
    });
  })();

  /* ---------- Individual clients slider ---------- */
  (function indivSlider() {
    var track = document.getElementById("individualTrack");
    if (!track) return;
    var slider = track.closest(".indiv-slider");
    var prev = slider.querySelector(".corp-arrow--prev");
    var next = slider.querySelector(".corp-arrow--next");
    function updateEdges() {
      var max = track.scrollWidth - track.clientWidth - 1;
      var atStart = track.scrollLeft <= 1, atEnd = track.scrollLeft >= max;
      slider.classList.toggle("at-start", atStart);
      slider.classList.toggle("at-end", atEnd || max <= 0);
      if (prev) prev.disabled = atStart;
      if (next) next.disabled = atEnd || max <= 0;
    }
    function page(dir) { track.scrollBy({ left: dir * Math.max(track.clientWidth * 0.7, 260), behavior: "smooth" }); }
    if (prev) prev.addEventListener("click", function () { page(-1); });
    if (next) next.addEventListener("click", function () { page(1); });
    track.addEventListener("scroll", updateEdges, { passive: true });
    window.addEventListener("resize", updateEdges);
    updateEdges();
  })();

  /* ---------- Choose your service (click/tap to toggle any number) ---------- */
  (function chooseService() {
    document.querySelectorAll(".svc-choice-list").forEach(function (list) {
      var choices = Array.prototype.slice.call(list.querySelectorAll(".svc-choice"));
      var form = list.closest(".contact-choose") ? list.closest(".contact-hero").querySelector("form") : null;
      var hidden = form ? form.querySelector('input[name="services"]') : null;
      function sync() {
        if (!hidden) return;
        hidden.value = choices.filter(function (c) { return c.classList.contains("is-selected"); })
          .map(function (c) { return c.dataset.service; }).join(", ");
      }
      choices.forEach(function (choice) {
        choice.addEventListener("click", function () {
          var selected = choice.classList.toggle("is-selected");
          choice.setAttribute("aria-pressed", selected ? "true" : "false");
          sync();
        });
      });

      // Preselect from ?service= query param (e.g. from a Start your project button)
      var params = new URLSearchParams(window.location.search);
      var pre = params.get("service");
      if (pre) {
        var wanted = pre.split(",").map(function (s) { return s.trim().toLowerCase(); });
        choices.forEach(function (c) {
          if (wanted.indexOf((c.dataset.service || "").toLowerCase()) > -1) {
            c.classList.add("is-selected");
            c.setAttribute("aria-pressed", "true");
          }
        });
        sync();
      }
    });
  })();

  /* ---------- Preloader (home only, first visit per session, reduced-motion aware) ---------- */
  (function preloader() {
    var el = document.getElementById("preloader");
    if (!el) return;
    function hide() { el.classList.add("is-hidden"); }
    var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var seen = false;
    try { seen = sessionStorage.getItem("perego-preloaded") === "1"; } catch (e) {}
    if (reduce || seen) { hide(); return; }
    try { sessionStorage.setItem("perego-preloaded", "1"); } catch (e) {}
    // hide shortly after first paint; do not wait for every image/resource
    setTimeout(hide, 900);
    window.addEventListener("load", function () { setTimeout(hide, 200); });
    // hard safety net so a JS/asset failure can never block the page
    setTimeout(hide, 2500);
  })();

  /* ---------- Portfolio archive filter (with no-results empty state) ---------- */
  (function portfolioFilter() {
    var grid = document.getElementById("portfolioGrid");
    if (!grid) return;
    var filters = [].slice.call(document.querySelectorAll(".portfolio-filter"));
    var cards = [].slice.call(grid.querySelectorAll("[data-category]"));
    var empty = document.getElementById("portfolioEmpty");
    filters.forEach(function (btn) {
      btn.addEventListener("click", function () {
        filters.forEach(function (b) { b.classList.remove("is-active"); b.setAttribute("aria-pressed", "false"); });
        btn.classList.add("is-active");
        btn.setAttribute("aria-pressed", "true");
        var f = btn.getAttribute("data-filter");
        var shown = 0;
        cards.forEach(function (c) {
          var show = f === "all" || c.getAttribute("data-category") === f;
          c.classList.toggle("is-hidden", !show);
          if (show) shown++;
        });
        if (empty) empty.hidden = shown !== 0;
      });
    });
  })();

})();

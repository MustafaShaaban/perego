# Reference screenshots

Captured references (1440-wide desktop):
- `01-home-en-desktop.png` — home, English (LTR).
- `02-home-rtl-layout.png` — home, RTL layout (direction/mirroring; body text swaps to Arabic from `content/ar.json` at build time — the live prototype flips direction only).
- `03-portfolio-en-desktop.png` — portfolio archive with service filters.

Fully-Arabic RTL rendering is demonstrated end-to-end by the email templates in `emails/ar/` (open any in a browser).

## Regenerate the full matrix
Open each page in `site/` and capture at 320 / 375 / 430 / 768 / 1024 / 1280 / 1440 in both languages (toggle AR/EN in the header). Priority states to capture per `docs/QA_CHECKLIST.md`: mobile nav open, service dropdown, hero slider controls, portfolio filtering + no-results, lightbox, form validation/success/error, empty search, and the 404 page. Arabic page captures become meaningful once the `content/*.json` bundle is wired into the templates in the CoreX build.

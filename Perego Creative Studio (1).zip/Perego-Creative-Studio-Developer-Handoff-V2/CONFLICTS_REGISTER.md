# CONFLICTS_REGISTER.md

Objective inconsistencies, contradictions, and missing states found while auditing the Final-Handoff prototype against the V2 requirements. Each entry has a **resolution** (what the spec now mandates) or is flagged **Open / needs Perego** where a design decision is required. This is **not** a redesign — brand, hierarchy, routes, copy, and concept are unchanged. Only objective defects are corrected.

Legend: ✅ resolved in V2 spec · ⚠️ open, needs Perego decision · 🔁 behaviour to add (spec-only; prototype code intentionally not modified in this pass).

---

## C-01 ✅ z-index scale contradicts itself
- **Found:** `design-tokens.json` declares `header:1000, navBackdrop:1100, navPanel:1200, skipLink:2000, lightbox:3000, preloader:4000`. But `site/css/styles.css` actually uses `header:100, nav-backdrop:150, main-nav:200, dropdown:120, skip-link:2000, lightbox:1800, preloader:2000`.
- **Impact:** The documented lightbox z-index (3000) never matches the rendered one (1800). An agent trusting tokens gets a different stacking result than the prototype. Risk: lightbox rendering under sticky UI, or preloader/skip-link tying.
- **Resolution:** `design-tokens.v2.json` defines a single reconciled scale (`z.header=1000, z.dropdown=1050, z.navBackdrop=1100, z.navPanel=1200, z.skipLink=1900, z.lightbox=3000, z.preloader=4000`). The **lightbox must sit above everything except the preloader**, and the preloader above all. CSS and tokens must use these names. Component specs reference the tokens, not raw numbers.

## C-02 ✅ Lightbox is `position:fixed` on `document.body` but not documented as a single global instance
- **Found:** `main.js` `lightbox()` creates **one** `.lightbox` element and appends it to `<body>` per page — good — but no spec stated the required placement, count, or stacking contract, and CSS `z-index:1800` (see C-01) is below the token intent.
- **Resolution:** `docs/components/global-media-lightbox.md` mandates exactly **one** instance per rendered page, appended as the **last child of `<body>`** (after footer, before `</body>`), using `z.lightbox`. It must never be duplicated per gallery/card and must not visually belong to the footer.

## C-03 🔁 Lightbox missing focus management, inertness, and media loading/error states
- **Found:** `main.js` lightbox opens/closes, supports prev/next/dots/Esc/backdrop, and clears the frame on close (which stops video). It does **not**: move focus into the dialog, trap focus, restore focus to the trigger, mark background `inert`/`aria-hidden`, expose `role="dialog"`/`aria-modal`, show a loading spinner, or show a designed media-error state.
- **Resolution (spec-only):** `docs/components/global-media-lightbox.md` §behaviour + §states specify the required dialog semantics, focus trap, focus restoration, background inertness, loading state, and error state. Prototype code is **not** modified in this pass (per instruction "document the correct target"); these are marked 🔁 for the CoreX build.

## C-04 ⚠️ Individual-client card performs BOTH navigate and open-lightbox on one click
- **Found (index.html):** each `.indiv-card` is `<a href="https://www.youtube.com" target="_blank" … data-video="…/embed/…">`. The anchor navigates to youtube.com in a new tab, **and** `main.js` lightbox binds a click that `preventDefault()`s and opens the embed. Two conflicting affordances on one element; behaviour depends on JS load order and is ambiguous.
- **V2 rule (§8.2, §15):** an individual-client card may open the lightbox **only when it has approved media**, via a **visible play affordance**; it must not also navigate. Cards without media are non-interactive.
- **Resolution:** `docs/components/individual-client-card.md` mandates: the card is a `<button>` (or the play button is the sole interactive control) that opens the lightbox when `mediaUrl` exists; **no `href` navigation**. Remove the `target="_blank"` youtube anchor pattern. **⚠️ Open:** confirm with Perego whether a "no-media" individual client should render at all, or be hidden.

## C-05 ⚠️ Corporate-client cards open a lightbox gallery
- **Found (main.js):** `corporateSlider()` generates `.corp-card` buttons with `data-gallery=` and they open the lightbox. The generated media is placeholder (`portfolio-*.png` + a Rickroll YouTube embed).
- **V2 rule (§8.2):** "Corporate client cards must not open a lightbox unless the approved design explicitly shows that behavior. Do not invent lightbox functionality for logos."
- **Resolution:** `docs/components/corporate-client-card.md` sets the **default** to non-interactive logo tiles (no lightbox). **⚠️ Open / needs Perego:** if corporate logos should open case-study media, that must be explicitly approved; until then, disable the lightbox trigger on `.corp-card` and replace the placeholder `corp-icon.png` with real logos.

## C-06 ✅ Placeholder media presented as if final
- **Found:** `portfolio-1…9.png`, `client-review-crop.png`, and the lightbox `pool[]` (including a Rickroll `dQw4w9WgXcQ` embed) are placeholders but appear throughout service pages, works archive, and clients.
- **Resolution:** All such assets are tagged **Placeholder requiring replacement** in `docs/CMS_VISUAL_CONTENT_MAP.md` and image specs. Golden screenshots capture them **as intentional approved placeholders** and the manifest marks these regions `dynamic`. Must be replaced with rights-cleared media before launch.

## C-07 ✅ File input shows only a filename swap; no true selected/validation/remove states
- **Found:** `.file-drop` swaps its label text to the filename and adds `.has-file`. `forms()` validates type/size **on submit only**. There is no persistent selected-file row (icon, size, status, Remove/Replace), no per-select validation display, no "remove and reselect same file".
- **V2 rule (§9):** full FileUploader with selected-file row, formatted size, status, Remove/Replace, per-select validation, long-filename truncation with accessible full name, and validation-persistence across other-field errors.
- **Resolution:** `docs/components/file-uploader.md` specifies the complete component and states. Marked 🔁 for the CoreX build; prototype code unchanged this pass.

## C-08 ✅ Service pages documented only as one generic template
- **Found:** legacy `docs/COMPONENTS.md` / `ROUTES_AND_TEMPLATES.md` treat the four service pages as one `service-single` template. The four prototype pages differ in hero title, "What we do" copy + `ui-*` image, process steps/icons, and selected-work filter; Website Making additionally has a filtered `web-showcase` grid instead of the masonry.
- **Resolution:** `docs/pages/` has **four separate** service manifests; `docs/sections/service-*.md` document shared vs unique properties explicitly (§14). Golden screenshots are produced per service.

## C-09 ✅ Header height / hero offset "magic numbers" undocumented
- **Found:** hero uses `margin-top:-94px; padding-top:94px`; inner pages use `-90px/90px`; header has no fixed height token (height derives from `padding-block:22px` + 46px logo ≈ 90px). The −94 vs −90 mismatch is undocumented.
- **Resolution:** `design-tokens.v2.json` defines `header.heightDesktop = 90px` and `header.heroOverlapDesktop = 90px`; the hero's historical `94px` is reconciled to **90px** (`header-height`) so overlap equals header height exactly. Flagged **Suggested** — verify no 4px seam appears at the hero top after unifying.

## C-10 ✅ "Clients" and "Contact" nav targets are section anchors, not the Contact route
- **Found (index nav):** "Contact Us" links to `#contact` (the footer on the homepage) while a header CTA and `contact.html` route also exist; "Clients" links to `index.html#clients`.
- **Resolution:** `docs/pages/_global-header.md` documents the exact link map and notes this is intentional (footer-as-contact on home; dedicated `contact.html` via CTA). No change to routes or copy.

---

## Open items requiring Perego sign-off (roll-up)
- **C-04** Individual-client card: navigate vs lightbox; render behaviour when no media.
- **C-05** Corporate-client logos: should they open a lightbox at all?
- **C-06** Supply real portfolio/client media + real lightbox media URLs.
- **C-09** Confirm unified 90px header/hero overlap shows no seam.

These must be resolved before any affected page is marked complete (`HANDOFF_AUTHORITY.md` §3).

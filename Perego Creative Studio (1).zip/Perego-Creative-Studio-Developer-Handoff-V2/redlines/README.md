# redlines/ — Annotated measurement overlays

**Status: PENDING GENERATION** (same capture constraint as `golden/` — see `../golden/README.md`).

Redlines are annotated versions of the golden screenshots. They must be produced **from the approved
golden captures** (not from estimation), once those exist. Do not measure from the live implementation.

## What to annotate (per §10)
For each complex page, section, and component, overlay:
- Container boundaries + max-content-width (1440 / gutter clamp(20,5vw,80))
- Horizontal + vertical spacing (section-y clamp(52,6.5vw,100), grid gaps)
- Grid measurements (service-cards 4-up, work-masonry 7-col placements, footer 3-col)
- Text baselines + text max-widths (hero text 1150, prose 760, desc 22ch)
- Media sizes + aspect ratios (service-card 5/6, corp 3/2, indiv card, tab 1/1, media 16/9)
- Border radii (card 29, btn 9, tab 20, corp 16, indiv 18, media 14) + shadow spreads
- Decorative asset placement (hero prism, wavy-corners, brand card, about focal 28%/72%)
- Alignment lines, component names, layer order, z-index
- Responsive deltas (annotate desktop AND mobile per section)
- Lightbox: dialog max 960 / media max-height 82vh, control positions (close -14/-14, nav ∓70 desktop / 8 mobile), dots/counter
- FileUploader: selected-row measurements, icon + Remove placement, ellipsis point

## How
Recommended: capture golden per `../golden/capture-recipe.js`, then annotate in Figma/any editor, OR
generate programmatically (draw rulers/labels over the PNG). Save as `redlines/<route-or-component>-<en|ar>-<desktop|mobile>-redline.png`. All measurements must equal the token/spec values in
`../design-tokens.v2.json` and the `docs/` specs — redlines and specs must never disagree.

## Priority order
1. Homepage hero, about, services-teaser, clients
2. Service hero + tabs, whatwedo, process, selected-work (§14/§15)
3. Global lightbox (all modes), FileUploader (all states)
4. Header/nav (all states), footer variants
5. Editorial (post/prose/legal/blog/pagination)

# Content EN ↔ AR Map

Both languages live in `content/en.json` and `content/ar.json` with an **identical key tree** — map by key path, not by position. Arabic is professional Modern Standard Arabic (MSA), meaning- and tone-preserving (not literal).

## How to use
- Load the bundle for the active language (`perego-lang` in localStorage, default `en`).
- English → `lang="en" dir="ltr"`, Open Sans. Arabic → `lang="ar" dir="rtl"`, **Cairo** (fallback Tajawal/Arial).
- Every visible string, placeholder, help text, validation/success/error message, pagination, breadcrumb, button, lightbox/slider control, and empty state is keyed. Do **not** hard-code copy or leave a mixed-language interface.

## Top-level key groups (same in both files)
`global` (brand, nav, headerCta, lang, skipToContent) · `services` (4 names + fullNames) · `home` (hero slides, about, servicesTeaser, clients) · `servicesOverview` (intro, process, closingCta) · `servicePages` (per-service subline/p1/p2/steps) · `portfolio` (filters, noResults) · `project` (field labels, section titles, cta) · `contact` (form labels/placeholders, chooser) · `footer` (contact, join, legalNav, copyright) · `journal` · `singlePost` (comments) · `search` · `page` · `legal` · `notFound` · `ui` (breadcrumb, pagination, lightbox, slider, loading) · `forms` (validation/success/error) · `contactInfo` (emails/phones — identical both languages).

## Selected term glossary (EN → AR)
| English | Arabic |
|---|---|
| Start a Project | ابدأ مشروعك |
| Our Services | خدماتنا |
| Video Editing | مونتاج الفيديو |
| 2D Motion Graphics | موشن جرافيك ثنائي الأبعاد |
| Graphic Design | التصميم الجرافيكي |
| Website Making | إنشاء المواقع |
| Our Work | أعمالنا |
| Contact Us | تواصل معنا |
| Journal | المدونة |
| Clients | عملاؤنا |
| Choose your service | اختر خدمتك |
| Send | إرسال |
| Apply now | قدّم الآن |
| Load more | عرض المزيد |
| No projects in this category yet… | لا توجد مشاريع في هذه الفئة بعد… |
| This field is required. | هذا الحقل مطلوب. |

## RTL rules
- Mirror layout via CSS logical properties (already in `styles.css`) — do not hard-flip with physical margins.
- Mirror directional icons (breadcrumb separators, prev/next arrows, dropdown carets, "start your project" arrows). Non-directional icons (play, social, equalizer, check) do **not** mirror.
- Keep LTR embedded runs readable inside RTL: phone numbers, emails, URLs, the Latin "Perego" wordmark, and `$` budget ranges. Use `dir="ltr"` spans / `unicode-bidi: isolate` around them.
- Long Arabic headings: nav labels and hero/section titles are longer in Arabic — the type scale uses `clamp()`, but re-test the nav (may wrap earlier than 1080px) and hero at 320–430px.
- Arabic form fields, errors, and email templates align to the inline-start (right); the email templates in `emails/ar/` already do this.

## Not translated (intentionally)
Brand Latin wordmark "Perego", email addresses, phone numbers, social platform names in URLs, and code/merge-field tokens (`{{name}}` etc.).

## Legal note
`legal.terms` / `legal.privacy` bodies are **draft** Arabic for layout only — carry `legal.reviewNote` and have a lawyer review before launch.

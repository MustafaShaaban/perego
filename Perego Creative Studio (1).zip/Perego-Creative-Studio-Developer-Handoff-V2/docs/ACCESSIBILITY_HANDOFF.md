# Accessibility Handoff (WCAG 2.2 AA target)

Two status levels below: **[DONE]** = implemented in this prototype; **[BUILD]** = specified requirement Claude Code must implement in the CoreX build (the prototype shows the design; the production component must add the noted semantics).

## Colour & contrast

- **[DONE]** Primary accent buttons (`.btn--accent`) now use **dark text `#2a0148` on `#d86af3`** (~7:1) instead of white (~2:1). Same fix applied to email CTAs and filter chips (`#12012e` on accent).
- **[DONE]** Body text is white on deep violet (far exceeds AA). Muted text uses `rgba(255,255,255,0.72)`; tertiary `0.55` — keep tertiary for labels/meta only, never for body paragraphs.
- **[DONE]** Field borders `rgba(216,106,243,0.5)` and placeholders `rgba(255,255,255,0.42)` are distinguishable on the dark fields.
- **[BUILD]** When placing dark text on the accent, keep it dark everywhere (badges, pills, active chips). Never white-on-accent.

## Focus & keyboard

- **[DONE]** Global `:focus-visible { outline: 2px solid var(--accent); outline-offset: 3px }`.
- **[DONE]** **Skip-to-content** link (`.skip-link` → `#main`, `tabindex="-1"` target) is the first focusable element on every page.
- **[DONE]** Nav, dropdown (hover + `:focus-within` + tap-accordion), language toggle, service chooser (buttons with `aria-pressed`), forms, pagination, filters, and all CTAs are keyboard-operable. Corporate-client tiles are real `<button>`s (were dead `<a href="#">`).
- **[BUILD]** **Mobile nav** must trap focus while open (first→last cycles), return focus to the hamburger on close, and set `aria-hidden`/`inert` on the rest of the page. Prototype already: Esc closes, backdrop closes, body scroll-locks.
- **[BUILD]** Logical tab order matches visual order in both LTR and RTL (CSS logical properties already mirror layout).

## Hero slider (auto-advances > 5s)

- **[DONE]** Auto-advance pauses on hover and when the tab is hidden; **disabled entirely under `prefers-reduced-motion`**; dot controls are real `<button role="tab">` with `aria-selected`.
- **[BUILD]** Add visible **Previous / Next** buttons and a **Pause/Play** toggle (labels in `content/*.json` → `ui.slider`). Auto-advance must **stop permanently after any manual interaction**. Add an `aria-live="polite"` region announcing "Slide X of 3". Keyboard: arrows move between slides when the slider has focus.

## Lightbox → accessible dialog

Prototype `.lightbox` has: open/close, prev/next, clickable dots, keyboard (Esc, ←/→), body scroll-lock, media-type detection (image / video / YouTube embed).
- **[BUILD]** Promote it to a real dialog: `role="dialog"` + `aria-modal="true"` + `aria-label` (from `ui.lightbox.title`); **focus trap** inside; **restore focus** to the triggering control on close; mark background `inert`; a visible **item counter** ("2 of 5", from `ui.lightbox.of`); captions via `aria-describedby`. Controls already exist as `<button>`s — add the dialog semantics + counter markup.

## Forms

- **[DONE]** Every field has a visible `<label for>`; errors render in a `.field-error` node with `aria-live="polite"`; invalid fields get `.has-error` (border + message, **not colour alone**). Success uses `role="status"`.
- **[DONE]** Service multi-select no longer needs the Shift key — each is a toggle `<button aria-pressed>`.
- **[BUILD]** Set `aria-invalid="true"` on errored inputs and `aria-describedby` pointing at the error node id. Add a form-level error summary (`role="alert"`) listing invalid fields on submit. Announce upload progress and server/rate-limit states via the live region (see `INTERACTIONS.md` for all states).

## Reduced motion

- **[DONE]** `prefers-reduced-motion: reduce` disables hero auto-rotation, scroll-reveal (content shown immediately), prism/wavy/equalizer loops, the preloader, and smooth scroll. Preserve every one of these guards in the rebuild.

## Progressive enhancement / no-JS

- **[DONE]** Reveal animations are gated behind a `.js` class added by `main.js` on init — **content is fully visible if JS fails or is disabled**. Client tiles, forms, and nav remain usable without JS.
- **[BUILD]** Corporate-client tiles are generated in JS in the prototype; in production render them (and any JS-generated content) server-side so they exist without JS. See `INTERACTIONS.md`.

## Landmarks & structure

- **[DONE]** `<header>`, `<nav aria-label>`, `<main id="main">`, `<footer>` on every page; one H1 per page (see `ROUTES_AND_TEMPLATES.md`); breadcrumbs use `<nav aria-label="Breadcrumb">`.
- **[BUILD]** Give the RTL build `lang="ar" dir="rtl"` at the document root; verify screen-reader reading order in Arabic.

# CMS_VISUAL_CONTENT_MAP.md

Every visible element → its content source and editability. Target CMS: **CoreX / WordPress** (custom fields + CPTs). Nothing visible is hardcoded unless tagged **Locked**. EN source = `content/en.json`; AR source = `content/ar.json` (mirror key structure). Translation behaviour: per-string, same keys both files.

Classes (per HANDOFF_AUTHORITY §2): Locked · Editable · Repeatable · Conditional · Decorative · Generated · Placeholder.

---

## Global

| Element | Component | Field | Type | Source | EN / AR | Class | Layout-affecting? | Empty behaviour |
|---|---|---|---|---|---|---|---|---|
| Logo | SiteHeader/Footer | site.logo | image | Options | logo-full.png / same | Locked | no | required |
| Nav items | SiteHeader | menu.primary[] | menu | WP menu | labels both | Editable/Repeatable | order only | must keep Home+Contact |
| Header CTA | SiteHeader | site.cta | text+url | Options | "Start a Project" | Editable | no | hide if empty |
| Contact emails/phones | Footer | site.contacts[] | text | Options | as-is | Editable | no | at least 1 |
| Footer blurb (contact) | Footer | footer.blurb | textarea | Options | both | Editable | minor | hide if empty |
| Footer "Join us" blurb | Footer | footer.join_blurb | textarea | Options | both | Editable | minor | hide |
| Social links | Footer | site.social[] | url[] | Options | n/a | Editable/Repeatable | no | hide icon if empty |
| Copyright year | Footer | — | — | JS | — | Generated | no | current year |
| Legal links | Footer | menu.legal | menu | WP | both | Editable | no | — |

## Home

| Element | Field | Type | Source | Class | Notes |
|---|---|---|---|---|---|
| Hero slides (title+body) ×3 | home.hero.slides[] | repeater(title, body_rich) | Options/Hero CPT | Editable/Repeatable | slide 1 title = H1; keep 3 for the dot pattern; long AR wraps |
| Hero CTA | home.hero.cta | text+url | Options | Editable | "Say Hello!" → contact |
| Hero background | home.hero.bg | image | Options | Locked/Decorative | hero-bg.png (LCP) |
| About title/body | home.about.* | text+rich | Options | Editable | 2 panels |
| Mission title/body | home.mission.* | text+rich | Options | Editable | |
| About bg figure | home.about.bg | image | Options | Locked/Decorative | about-hooded.png |
| Services teaser heading + See-all | home.services.* | text+url | Options | Editable | |
| Service cards ×4 (label, image, link) | services[] | CPT (title, card_image, url) | Service CPT | Repeatable | fixed 4; NAVIGATE (no lightbox); card-*.png |
| Corporate clients | clients.corporate[] | repeater(logo, name, url?) | Clients CPT | Repeatable | logos only; **no lightbox by default (C-05)**; corp-icon.png = Placeholder |
| Individual clients | clients.individual[] | repeater(title, sub, stat, thumb, media_url?) | Clients CPT | Repeatable/Conditional | play + lightbox ONLY if media_url set (C-04); client-review-crop.png = Placeholder |

## Services overview + service pages

| Element | Field | Type | Source | Class |
|---|---|---|---|---|
| Service H1 | service.title | text | Service CPT | Editable |
| Service hero bg | service.hero_bg | image | Options (shared) | Locked/Decorative (svc-hero-bg.png) |
| Tabs (4) | services[] | CPT | Service CPT | Repeatable (fixed 4) |
| What-we-do subline + 2 paras | service.whatwedo.* | text+rich | Service CPT | Editable |
| What-we-do media | service.whatwedo.image | image | Service CPT | Editable (ui-*.png; website reuses graphic — see image spec) |
| Process steps ×4 (label, desc, icon) | service.process[] | repeater | Service CPT | Repeatable/Editable | icons from fixed set |
| Selected work items | service.work[] (filter=slug) | relation → Project CPT | Project CPT | Repeatable/Conditional |
| Work item media | project.media[] (image/video/gallery) | mixed | Project CPT | see lightbox media rules below |
| Website showcase cards | websites[] (title, url, category, shot) | CPT | Website CPT | Repeatable (website-making only) |

## Work / Project / Journal / Search / Legal

| Element | Field | Source | Class | Interaction |
|---|---|---|---|---|
| Project cards (archive) | projects[] | Project CPT | Repeatable | NAVIGATE to project |
| Filters | fixed taxonomy (video/motion/design/web) | Taxonomy | Locked | filter |
| Project hero (cat, title, lead) | project.* | Project CPT | Editable | |
| Project gallery items | project.gallery[] | Project CPT | Repeatable/Conditional | OPEN lightbox (image/gallery/video) |
| Journal cards | posts[] | Post CPT | Repeatable | NAVIGATE (no lightbox on article images, §8.2) |
| Post body | post.content | Post CPT | Editable/rich | |
| Comments | post.comments[] | WP comments | Repeatable | Placeholder in prototype |
| Search results | query results | search | Repeatable/Conditional | NAVIGATE; no-results empty state |
| Legal body | legal.content | Page | Editable (DRAFT — counsel) | TOC generated |

## Lightbox media records (per §8 / §12)
Each media item must specify: **media_type** (image/video/gallery) · **image_url** · **video/embed_url** · **gallery_order** · **caption** · **alt** · **poster** · **show_trigger** (bool) · **empty behaviour** (if the media field is empty → hide the trigger; the card falls back to its documented non-media state; never render an empty lightbox). The lightbox `pool[]` in the prototype (incl. a Rickroll embed) is **Placeholder** — replace with real URLs.

## Upload fields (per §9 / §12)
For each upload (footer "Join us" CV; any project-brief/careers form): **accepted types** `.pdf,.doc,.docx` · **max size** 10 MB · **max count** 1 · **email attachment behaviour** (attach or secure admin link) · **storage** · **admin submission visibility** · **filename preservation** (must keep original name) · **security validation** (type + size + scan) · **retention policy**. See docs/components/file-uploader.md and docs/EMAIL_HANDOFF.md.

## Locked visuals (never CMS-driven)
All gradients, radii (card 29 / btn 9 / tab 20 / etc.), shadows, decorative layers (hero prism, wavy-corners, footer texture, brand card), stagger offsets, z-index scale, motion timings. Editors change **content**, not these.

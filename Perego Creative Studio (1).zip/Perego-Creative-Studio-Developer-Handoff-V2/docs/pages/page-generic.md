route: /:page (generic CMS page)
template: page
page_title: "<Page title> — Perego"
baseline: prototype-derived (site/page.html) — pending Perego sign-off
golden: [golden/page-generic-en-desktop-1440.png, golden/page-generic-ar-desktop-1440.png, golden/page-generic-en-mobile-390.png, golden/page-generic-ar-mobile-390.png]

sections:
  - id: global-header
    component: SiteHeader
    variant: solid
    required: true
  - id: page-hero
    component: LegalOrPageHero
    required: true
    notes: 'Centered title + optional lead.'
  - id: page-body
    component: Prose
    required: true
    class: cms-editable
    notes: 'Generic prose column for flexible CMS content.'
  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true

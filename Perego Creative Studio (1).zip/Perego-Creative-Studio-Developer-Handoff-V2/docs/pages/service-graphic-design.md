route: /services/graphic-design
template: service-single
page_title: "Graphic Design & Brand Identity — Perego"
baseline: prototype-derived (site/service-graphic-design.html) — pending Perego sign-off
golden: [golden/service-graphic-design-en-desktop-1440.png, golden/service-graphic-design-ar-desktop-1440.png, golden/service-graphic-design-en-mobile-390.png, golden/service-graphic-design-ar-mobile-390.png]
tablet_capture_required: true

# UNIQUE content is called out; SHARED structure is identical across all four service pages.
# See docs/sections/service-pages.md for the full shared-vs-unique matrix (§14).

sections:
  - id: global-header
    component: SiteHeader
    variant: overlay
    active_item: services            # Services PARENT is active on every service page
    required: true

  - id: service-hero
    component: ServiceHero
    variant: graphic-design
    required: true
    class: locked-visual + cms-editable(h1)
    notes: >
      svc-hero (min-height 92vh) over svc-hero-bg.png (SHARED bg). Eyebrow "Our Services" (SHARED).
      H1 (UNIQUE) = "Graphic Design & Brand Identity". Then svc-tabs (SHARED 4 tiles); the tile for THIS service has
      .is-active and its main link has aria-current="page". Tiles navigate; never lightbox.

  - id: what-we-do
    component: ServiceCapabilities
    variant: graphic-design
    required: true
    class: cms-editable
    notes: >
      SHARED layout (2-col grid, media rotated -1.2deg). H2 "What we do" (SHARED).
      subline (UNIQUE) = "Graphic Design & Brand Identity". Two paragraphs (UNIQUE). media (UNIQUE) = ui-graphic-design.png.

  - id: process
    component: ServiceProcess
    required: true
    class: cms-editable(labels) + locked-visual(layout)
    notes: >
      SHARED 4-step layout on gradient-process, arrows between steps. Steps (UNIQUE):
      Brand Understanding (icon-hands) -> Visual Direction (icon-star) -> Design Execution (icon-pen) -> Review & Delivery (icon-film-h)

  - id: selected-work
    component: SelectedWorkGallery
    variant: masonry
    filter: graphic-design
    required: true
    media_interaction: global-lightbox
    notes: >
      SHARED 15-tile work-masonry (m1..m15) + non-interactive work-brand card + hidden work-more grid (8) + Load more. Tiles carry data-video / data-image / data-gallery => open the global lightbox in video / image / gallery mode. Media set is UNIQUE per service (filter=graphic-design).

  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true

global_components:
  - { component: GlobalMediaLightbox, placement: last child of body, instances: 1, opened_by: [selected-work items] }

# RTL: full mirror. Tabs grid + process flow mirror; process-arrow glyphs flip (scaleX-1),
# and stack vertically (rotate 90deg) below 620px in BOTH directions.

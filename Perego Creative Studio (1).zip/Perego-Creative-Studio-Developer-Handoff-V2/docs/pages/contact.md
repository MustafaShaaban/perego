route: /contact
template: contact
page_title: "Start a Project — Perego"
baseline: prototype-derived (site/contact.html) — pending Perego sign-off
golden: [golden/contact-en-desktop-1440.png, golden/contact-ar-desktop-1440.png, golden/contact-en-mobile-390.png, golden/contact-ar-mobile-390.png]
tablet_capture_required: true

sections:
  - id: global-header
    component: SiteHeader
    variant: overlay
    active_item: contact
    required: true
  - id: contact-hero
    component: ContactHero
    required: true
    class: locked-visual + functional(form)
    notes: >
      Full-height contact-hero over about-hooded.png (dimmed). sr-only H1 "Start a Project".
      2-col grid: LEFT .contact-form-wrap (glass) with .page-form.contact-form; RIGHT .contact-choose
      ("Choose your service" — svc-choice toggle buttons Video/Motion/Design/Web, multi-select,
      aria-pressed, writes hidden input[name=services]; preselect via ?service= query).
      MOBILE order: .contact-choose has order:-1 => "Choose your service" appears ABOVE the form.
      Watermark logo below choices.
  - id: global-footer
    component: SiteFooter
    variant: flat          # site-footer--flat: solid gradient, no texture, 2-col >=901px
    required: true

# Form: see docs/components/forms.md + file-uploader.md. Choose-service preselect feeds the CoreX form.

route: /work
template: work-archive
page_title: "Our Work — Perego"
baseline: prototype-derived (site/portfolio.html) — pending Perego sign-off
golden: [golden/work-archive-en-desktop-1440.png, golden/work-archive-ar-desktop-1440.png, golden/work-archive-en-mobile-390.png, golden/work-archive-ar-mobile-390.png]
tablet_capture_required: true   # blog-grid 3->2->1 col at 900/640

sections:
  - id: global-header
    component: SiteHeader
    variant: solid
    active_item: work
    required: true
  - id: archive-head
    component: ArchiveHead
    required: true
    notes: 'Centered breadcrumb (Home / Work), H1 "Our Work", lead. class: cms-editable(copy).'
  - id: portfolio-filters
    component: PortfolioFilters
    required: true
    class: locked-visual + conditional(empty-state)
    notes: >
      Pill filter buttons (.web-filter.portfolio-filter): All Projects / Video Editing / 2D Motion
      Graphics / Graphic Design / Website Making. data-filter = all|video|motion|design|web.
      Uses aria-pressed. Filtering toggles .is-hidden on cards; when 0 match, #portfolioEmpty shows.
  - id: portfolio-grid
    component: PortfolioCardGrid
    required: true
    class: repeatable
    media_interaction: navigate   # each .post-card is an <a href="project.html"> => NAVIGATES to case study
    notes: >
      3-col blog-grid of .post-card (media + cat + title + excerpt + meta), each data-category.
      IMPORTANT (§8.2): the card link NAVIGATES to the project page. It does NOT open a lightbox.
      A separate media affordance (zoom/play) is only added if the approved design shows one.
  - id: empty-state
    component: EmptyState
    required: true
    class: conditional
    notes: '#portfolioEmpty (hidden by default) — "No projects in this category yet. Try another filter."'
  - id: pagination
    component: Pagination
    required: true
    notes: 'Prev (disabled on p1) / numbered / Next. .is-current = accent. 44px min touch target.'
  - id: cta-band
    component: CtaBand
    required: true
    notes: '"Have a project in mind?" + Start a Project. Top hairline border.'
  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true

# NOTE: cards are PLACEHOLDER projects (portfolio-*.png). Replace with real, rights-cleared work.

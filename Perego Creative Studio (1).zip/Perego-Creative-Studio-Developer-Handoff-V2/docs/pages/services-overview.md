route: /services
template: services-overview
page_title: "Our Services — Video, Motion, Design & Web | Perego"
baseline: prototype-derived (site/services.html) — pending Perego sign-off
golden: [golden/services-en-desktop-1440.png, golden/services-ar-desktop-1440.png, golden/services-en-mobile-390.png, golden/services-ar-mobile-390.png]
tablet_capture_required: true

sections:
  - id: global-header
    component: SiteHeader
    variant: overlay
    active_item: services   # Services parent .is-active
    required: true
  - id: svc-hero
    component: ServiceHero
    variant: overview
    required: true
    class: locked-visual + repeatable(4 tabs)
    notes: >
      Centered svc-hero (min-height 92vh) over svc-hero-bg.png. H1 = "Our Services" (NO eyebrow on
      overview; the four service pages DO have the "Our Services" eyebrow). Below: svc-tabs nav = 4
      glass tiles, NONE active on overview. Each tile: label + hidden "Start your project" CTA that
      reveals on hover/active. Tiles NAVIGATE to service pages (never lightbox).
  - id: what-we-do
    component: ServiceCapabilities
    variant: overview
    required: true
    notes: 'H2 "One studio, four services"; subline "Video · Motion · Design · Web"; 2 paras; media ui-video-editing.png (rotated -1.2deg).'
  - id: process
    component: ServiceProcess
    required: true
    notes: 'Steps: Discover / Concept / Create / Deliver. Icons clapper, film-l, star, film-h.'
  - id: selected-work
    component: SelectedWorkGallery
    variant: masonry
    required: true
    media_interaction: global-lightbox
    notes: 'H2 "Selected work". 15-tile masonry + brand card + hidden work-more grid + Load more.'
  - id: cta-band
    component: CtaBand
    required: true
    notes: 'Centered "Have a project in mind?" + lead + "Start a Project" button → contact.html. (Overview-only section; NOT on the four service pages.)'
  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true

global_components:
  - { component: GlobalMediaLightbox, placement: last child of body, instances: 1, opened_by: [selected-work tiles] }

# docs/pages/ — Page composition manifests

One manifest per route. Each lists **every section in exact approved visual order**, with component,
variant, required/optional, content source, CMS editability, media-interaction (navigate vs
global-lightbox), and the single global lightbox placement. No section may be inferred from another
page — every page has a complete inventory here.

Routes:
- home.md, services-overview.md
- service-video-editing.md, service-motion-graphics.md, service-graphic-design.md, service-website-making.md  (four SEPARATE manifests, §14)
- work-archive.md, project.md, contact.md
- journal-archive.md, journal-single.md, search.md, page-generic.md
- terms.md, privacy.md, 404.md
- _global-partials.md  (SiteHeader / SiteFooter, referenced by every page)

Media-interaction rule of thumb (§8.2):
- NAVIGATE: service cards/tabs, work-archive project cards, journal cards, related cards.
- OPEN GLOBAL LIGHTBOX: selected-work tiles (services + service pages), project-gallery thumbs,
  individual-client card (only when media exists), website-showcase card shot.
- NEVER lightbox: corporate logos (default), journal article images.

# Global partials — Header & Footer

Included on every route. Documented once here; page manifests reference them as `global-header` / `global-footer`.

---

## `global-header` — component `SiteHeader`

- **DOM:** `header.site-header#siteHeader > .container.site-header__inner` containing, in order: `.logo` (img `logo-full.png`, 46px tall) · `nav.main-nav#mainNav` (primary) · `a.btn.btn--accent.header-cta` ("Start a Project" → `contact.html`) · `.lang-toggle` (AR / EN buttons) · `button.nav-toggle#navToggle` (hamburger). Followed by sibling `div.nav-backdrop#navBackdrop`.
- **Variant:** `overlay` on hero pages (home, service, services, contact) — header is transparent and the first section pulls up under it by `header-hero-overlap-desktop` (90px). `solid` context otherwise (editorial pages) — header still `position:sticky; top:0` and gains `.is-scrolled` after `scrollY > 20`.
- **Class:** Locked visual (chrome) + CMS editable (nav labels/order via menu).
- **Nav link map (exact, unchanged):** Home `index.html#hero` · About Us `index.html#about` · **Services** (has-dropdown → 4 service pages) · Work `portfolio.html` · Journal `archive.html` · Clients `index.html#clients` · Contact Us `#contact` (footer anchor on home; on inner pages resolves to the footer `#contact`). See CONFLICTS C-10.
- **Active state:** the page's own nav item carries `.is-active` (animated 2px accent underline `scaleX`). Service pages set `.is-active` on the **Services** parent.
- **EN/AR:** logical properties throughout; the whole bar mirrors in RTL. Lang toggle persists to `localStorage['perego-lang']`; on load, saved lang re-applies `dir`/`lang`/`body.lang-ar`.
- **Desktop:** row, `gap: clamp(20px,3vw,48px)`, `padding-block:22px`. **Mobile (≤1024px):** hamburger shows; `.main-nav` becomes a fixed right-side (RTL: left) panel `min(320px,84vw)`, slide-in `translateX`, with `.nav-backdrop`; header CTA hidden; body scroll-locked via `body.nav-locked`.
- **See:** `docs/components/site-header.md`, `docs/components/services-dropdown.md`, `docs/components/mobile-navigation.md`, `docs/components/language-switcher.md`.

## `global-footer` — component `SiteFooter`

- **DOM:** `footer.site-footer#contact` with inline social SVG sprite, then `.container.site-footer__grid` (3 columns), then `.container.site-footer__bottom` (copyright + legal links).
- **Columns:** (1) `.footer-contact` — logo, "Contact us" heading, 4 contact links (2 emails, 2 phones), blurb, 5 social icons. (2) contact `form.footer-form` (name, email, message, Send). (3) "Join us" — blurb + `form.footer-form` (name, portfolio URL, CV `file-drop`, Apply now).
- **Variants:** `standard` (default; has `footer.png` texture via `::before`). `flat` = `.site-footer--flat` (solid gradient, no texture; contact page; 2-col grid ≥901px). `min` = `.site-footer--min` (contact bottom-only).
- **Class:** Locked visual (layout) · CMS editable (contact details, blurbs, social URLs) · form actions Functional.
- **Contact details (real, do not alter):** mostafa.emam3313@gmail.com · yehemam2@gmail.com · +996 56 293 2759 · +20 111 54 855 72.
- **Responsive:** 3-col → 1-col at 900px (dividers switch from inline-start borders to block-start borders); bottom bar centers ≤560px.
- **Copyright:** "© {year} Perego Creative Studio — بيريجو. All rights reserved." `{year}` is **Generated** (JS `#year`).
- **See:** `docs/components/site-footer.md`, `docs/components/forms.md`, `docs/components/file-uploader.md`.

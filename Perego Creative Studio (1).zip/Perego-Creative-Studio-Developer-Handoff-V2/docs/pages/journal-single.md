route: /journal/:slug
template: journal-single
page_title: "<Post title> — Perego"
baseline: prototype-derived (site/single-post.html) — pending Perego sign-off
golden: [golden/journal-single-en-desktop-1440.png, golden/journal-single-ar-desktop-1440.png, golden/journal-single-en-mobile-390.png, golden/journal-single-ar-mobile-390.png]
tablet_capture_required: true

sections:
  - id: global-header
    component: SiteHeader
    variant: solid
    required: true
  - id: post-hero
    component: PostHero
    required: true
    notes: 'Centered post-cat pill + H1 post-title + post-meta (avatar/author/date/read-time) + post-featured image (16:8).'
  - id: post-body
    component: Prose
    required: true
    class: cms-editable
    notes: 'Reading column max 760px, 17px/1.8. h2/h3/blockquote/lists/figure/code styles per styles.css .prose. Article images do NOT open the lightbox (§8.2).'
  - id: post-foot
    component: PostFooter
    required: true
    notes: 'Tags (post-tag pills) + author-box.'
  - id: comments
    component: Comments
    required: true
    class: repeatable + functional
    notes: 'Threaded comment-list (comment / comment--reply) + comment-form. PLACEHOLDER comments.'
  - id: related
    component: RelatedProjects
    notes: 'Related posts grid (navigate).'
  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true

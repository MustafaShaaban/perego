route: /journal
template: journal-archive
page_title: "Journal — Perego"
baseline: prototype-derived (site/archive.html) — pending Perego sign-off
golden: [golden/journal-archive-en-desktop-1440.png, golden/journal-archive-ar-desktop-1440.png, golden/journal-archive-en-mobile-390.png, golden/journal-archive-ar-mobile-390.png]
tablet_capture_required: true   # blog-grid 3->2->1

sections:
  - id: global-header
    component: SiteHeader
    variant: solid
    active_item: journal
    required: true
  - id: archive-head
    component: ArchiveHead
    notes: 'Breadcrumb + H1 "Journal" + section-lead.'
    required: true
  - id: journal-grid
    component: JournalCardGrid
    required: true
    class: repeatable
    media_interaction: navigate   # journal cards NAVIGATE to the article; NEVER open the lightbox (§8.2)
    notes: '3-col blog-grid of .post-card => link to single-post.html. Article images do NOT open the global lightbox.'
  - id: pagination
    component: Pagination
    required: true
  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true

# NOTE: posts are PLACEHOLDER. Replace with real journal content.

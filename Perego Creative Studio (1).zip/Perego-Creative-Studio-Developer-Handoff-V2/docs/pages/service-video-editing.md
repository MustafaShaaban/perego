route: /services/video-editing
template: service-single
page_title: "Video Editing & Post-Production — Perego"
baseline: prototype-derived (site/service-video-editing.html) — pending Perego sign-off
golden: [golden/service-video-editing-en-desktop-1440.png, golden/service-video-editing-ar-desktop-1440.png, golden/service-video-editing-en-mobile-390.png, golden/service-video-editing-ar-mobile-390.png]
tablet_capture_required: true

# UNIQUE content is called out; SHARED structure is identical across all four service pages.
# See docs/sections/service-pages.md for the full shared-vs-unique matrix (§14).

sections:
  - id: global-header
    component: SiteHeader
    variant: overlay
    active_item: services            # Services PARENT is active on every service page
    required: true

  - id: service-hero
    component: ServiceHero
    variant: video-editing
    required: true
    class: locked-visual + cms-editable(h1)
    notes: >
      svc-hero (min-height 92vh) over svc-hero-bg.png (SHARED bg). Eyebrow "Our Services" (SHARED).
      H1 (UNIQUE) = "Video Editing & Post-Production". Then svc-tabs (SHARED 4 tiles); the tile for THIS service has
      .is-active and its main link has aria-current="page". Tiles navigate; never lightbox.

  - id: what-we-do
    component: ServiceCapabilities
    variant: video-editing
    required: true
    class: cms-editable
    notes: >
      SHARED layout (2-col grid, media rotated -1.2deg). H2 "What we do" (SHARED).
      subline (UNIQUE) = "Video Editing & Post-Production". Two paragraphs (UNIQUE). media (UNIQUE) = ui-video-editing.png.

  - id: process
    component: ServiceProcess
    required: true
    class: cms-editable(labels) + locked-visual(layout)
    notes: >
      SHARED 4-step layout on gradient-process, arrows between steps. Steps (UNIQUE):
      Footage Review (icon-clapper) -> Creative Editing (icon-film-l) -> Effects & Refinement (icon-star) -> Delivery & Revisions (icon-film-h)

  - id: selected-work
    component: SelectedWorkGallery
    variant: masonry
    filter: video-editing
    required: true
    media_interaction: global-lightbox
    notes: >
      SHARED 15-tile work-masonry (m1..m15) + non-interactive work-brand card + hidden work-more grid (8) + Load more. Tiles carry data-video / data-image / data-gallery => open the global lightbox in video / image / gallery mode. Media set is UNIQUE per service (filter=video-editing).

  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true

global_components:
  - { component: GlobalMediaLightbox, placement: last child of body, instances: 1, opened_by: [selected-work items] }

# RTL: full mirror. Tabs grid + process flow mirror; process-arrow glyphs flip (scaleX-1),
# and stack vertically (rotate 90deg) below 620px in BOTH directions.

route: /
template: home
page_title: "Perego — Creative Studio"
baseline: prototype-derived (site/index.html) — pending Perego sign-off
golden:
  - golden/home-en-desktop-1440.png
  - golden/home-ar-desktop-1440.png
  - golden/home-en-mobile-390.png
  - golden/home-ar-mobile-390.png
tablet_capture_required: true   # about → 1col at 900, service-cards → 2up at 680, nav → hamburger at 1024

# Sections in exact approved visual order. No section may be inferred from another page.
sections:
  - id: preloader
    component: Preloader
    required: true
    class: generated
    notes: >
      Home only. First visit per session (sessionStorage 'perego-preloaded'), reduced-motion aware,
      hard-hides by 2500ms safety net. z=preloader(4000). Not present on other routes.

  - id: global-header
    component: SiteHeader
    variant: overlay
    required: true
    active_item: home

  - id: hero
    component: HomeHero
    required: true
    class: locked-visual + cms-editable(text)
    source: options-page / hero slides CPT
    media_interaction: none
    notes: >
      Full-viewport (min-height:100vh) prism-background slider. 3 text slides, auto-rotate 6500ms,
      pause on hover/tab-hidden. Dots = tablist. CTA "Say Hello!" → contact.html.
      Slide 1 h1 = "What We Believe"; slides 2 & 3 use p.hero__title (only slide 1 is the H1).
    entry: top of document under overlay header (overlap 90px)
    exit: scrolls into #about

  - id: about
    component: HomeAbout
    required: true
    class: locked-visual + cms-editable(text)
    source: options-page
    notes: >
      Full-bleed 'about-hooded.png' bg (object-position 28% center; RTL 72%) with directional
      gradient scrim; two .glass-panel cards ("About Us", "Our mission") right-aligned in a
      1fr / minmax(0,620px) grid (RTL: left column). Reveal-on-scroll.

  - id: services
    component: ServicesTeaser
    required: true
    class: locked-visual + repeatable(4 cards)
    source: service CPT (4 fixed services)
    media_interaction: navigate   # cards NAVIGATE to service pages — never lightbox (see §15)
    notes: >
      bg = gradient-page + wavy-corners overlay(0.6). Head "Services we can help you with" +
      "See All Services" link-arrow → services.html. 4 .service-card links, staggered vertical
      offsets (nth-2, nth-4), aspect 5/6, radius 29. Hover lift + accent inner ring.

  - id: clients
    component: ClientsSection
    required: true
    class: locked-visual + repeatable + conditional(media)
    source: clients CPT (corporate + individual)
    media_interaction: see-notes
    notes: >
      Two blocks. Corporate: 2-row horizontal scroller of .corp-card logo tiles (arrows, edge fades,
      drag). Individual: horizontal scroller of .indiv-card (title/sub/stat + thumb + play).
      CONFLICTS C-04/C-05: corporate tiles must NOT open lightbox by default; individual cards open
      lightbox ONLY when media exists, via the play affordance, and must NOT also navigate.

  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true
    anchor: "#contact"

global_components:
  - component: GlobalMediaLightbox
    placement: last child of <body>, after footer
    instances: 1
    z: lightbox(3000)
    opened_by: [individual-client card play button (conditional)]
    not_opened_by: [service cards, corporate logos (default)]

# RTL summary: entire layout mirrors via logical properties. about bg focal + gradient flip;
# service-card stagger unchanged; slider direction + arrow glyphs mirror. Text = Cairo.

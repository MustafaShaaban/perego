route: /terms
template: legal
page_title: "Terms & Conditions — Perego"
baseline: prototype-derived (site/terms.html) — pending Perego sign-off  |  DRAFT: legal body must be reviewed by counsel
golden: [golden/terms-en-desktop-1440.png, golden/terms-ar-desktop-1440.png, golden/terms-en-mobile-390.png, golden/terms-ar-mobile-390.png]

sections:
  - id: global-header
    component: SiteHeader
    variant: solid
    required: true
  - id: legal-hero
    component: LegalHero
    required: true
    notes: 'Centered H1 "Terms & Conditions" + "Last updated" line.'
  - id: legal-layout
    component: LegalLayout
    required: true
    class: cms-editable(body) + generated(toc-active)
    notes: >
      2-col: sticky legal-toc (numbered anchor list, scroll-spy .is-active) + legal-body prose.
      Section headings use .num accent numbering, scroll-margin-top 110px. Collapses to 1col at 900px
      (TOC becomes static). Body is a LAYOUT DRAFT — replace with counsel-approved text.
  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true

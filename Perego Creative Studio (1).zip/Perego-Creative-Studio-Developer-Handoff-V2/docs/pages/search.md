route: /search
template: search-results
page_title: "Search — Perego"
baseline: prototype-derived (site/search.html) — pending Perego sign-off
golden: [golden/search-en-desktop-1440.png, golden/search-ar-desktop-1440.png, golden/search-en-mobile-390.png, golden/search-ar-mobile-390.png]

sections:
  - id: global-header
    component: SiteHeader
    variant: solid
    required: true
  - id: search-head
    component: SearchHead
    required: true
    notes: 'H1 + .search-bar (pill: icon + input + Search button). Populated and no-results states both documented (see component states).'
  - id: results-grid
    component: PortfolioCardGrid
    required: true
    class: repeatable + conditional
    media_interaction: navigate
    notes: 'blog-grid of result cards => navigate. No-results => empty-state message.'
  - id: pagination
    component: Pagination
  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true

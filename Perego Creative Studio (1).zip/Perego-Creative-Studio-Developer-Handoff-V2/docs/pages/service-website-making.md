route: /services/website-making
template: service-single
page_title: "Website Making & Development — Perego"
baseline: prototype-derived (site/service-website-making.html) — pending Perego sign-off
golden: [golden/service-website-making-en-desktop-1440.png, golden/service-website-making-ar-desktop-1440.png, golden/service-website-making-en-mobile-390.png, golden/service-website-making-ar-mobile-390.png]
tablet_capture_required: true

# UNIQUE content is called out; SHARED structure is identical across all four service pages.
# See docs/sections/service-pages.md for the full shared-vs-unique matrix (§14).

sections:
  - id: global-header
    component: SiteHeader
    variant: overlay
    active_item: services            # Services PARENT is active on every service page
    required: true

  - id: service-hero
    component: ServiceHero
    variant: website-making
    required: true
    class: locked-visual + cms-editable(h1)
    notes: >
      svc-hero (min-height 92vh) over svc-hero-bg.png (SHARED bg). Eyebrow "Our Services" (SHARED).
      H1 (UNIQUE) = "Website Making". Then svc-tabs (SHARED 4 tiles); the tile for THIS service has
      .is-active and its main link has aria-current="page". Tiles navigate; never lightbox.

  - id: what-we-do
    component: ServiceCapabilities
    variant: website-making
    required: true
    class: cms-editable
    notes: >
      SHARED layout (2-col grid, media rotated -1.2deg). H2 "What we do" (SHARED).
      subline (UNIQUE) = "Website Making & Development". Two paragraphs (UNIQUE). media (UNIQUE) = ui-graphic-design.png  # NOTE: reuses graphic-design UI image; no ui-website asset exists (see image spec / CONFLICTS if a dedicated asset is required).

  - id: process
    component: ServiceProcess
    required: true
    class: cms-editable(labels) + locked-visual(layout)
    notes: >
      SHARED 4-step layout on gradient-process, arrows between steps. Steps (UNIQUE):
      Discovery & Goals (icon-hands) -> Wireframe & Design (icon-browser) -> Build & Develop (icon-laptop) -> Launch & Support (icon-film-h)

  - id: selected-work
    component: WebsiteShowcase
    variant: filtered-grid
    filter: website-making
    required: true
    media_interaction: global-lightbox
    notes: >
      UNIQUE to Website Making: instead of the masonry, this page uses .web-showcase — a filterable 2-col grid of browser-chrome cards (traffic lights + URL bar + screenshot). Head 'Websites we\u2019ve built'. Filters: All / E-Commerce / Corporate / (more). Clicking a card SHOT opens the global lightbox (image mode); the 'Visit' link navigates externally. Grid -> 1col at 720px.

  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true

global_components:
  - { component: GlobalMediaLightbox, placement: last child of body, instances: 1, opened_by: [selected-work items] }

# RTL: full mirror. Tabs grid + process flow mirror; process-arrow glyphs flip (scaleX-1),
# and stack vertically (rotate 90deg) below 620px in BOTH directions.

route: /work/:slug   (project case study)
template: project-single
page_title: "<Project title> — Perego"
baseline: prototype-derived (site/project.html) — pending Perego sign-off
golden: [golden/project-en-desktop-1440.png, golden/project-ar-desktop-1440.png, golden/project-en-mobile-390.png, golden/project-ar-mobile-390.png]
tablet_capture_required: true

sections:
  - id: global-header
    component: SiteHeader
    variant: solid
    required: true
  - id: project-hero
    component: ProjectHero
    required: true
    class: cms-editable
    notes: >
      Centered breadcrumb (Home / Work / Project), post-cat pill (service), H1 project title,
      section-lead. Example content — replace with real project data.
  - id: project-body
    component: ProjectBody
    required: true
    class: cms-editable
    notes: 'Prose intro / details column (max 760px).'
  - id: project-gallery
    component: ProjectGallery
    required: true
    class: repeatable
    media_interaction: global-lightbox   # thumbnails OPEN the lightbox (image/gallery/video)
    notes: >
      H2 "Project gallery" + work-masonry of thumbs. Each thumb carries data-image / data-gallery /
      data-video and opens the global lightbox in the matching mode (one image => image; multiple
      => gallery; video => video). This is the approved lightbox trigger for the project page (§8.2).
  - id: related-projects
    component: RelatedProjects
    required: true
    media_interaction: navigate
    notes: 'H2 "Related projects" + post-card grid => NAVIGATE to other project pages.'
  - id: global-footer
    component: SiteFooter
    variant: standard
    required: true

global_components:
  - { component: GlobalMediaLightbox, placement: last child of body, instances: 1, opened_by: [project-gallery thumbnails] }

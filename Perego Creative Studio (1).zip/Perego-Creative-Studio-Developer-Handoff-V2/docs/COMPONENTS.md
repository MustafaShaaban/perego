# Components

Each component: variants · states · responsive · RTL · content limits · a11y. Classes reference `site/css/styles.css`.

## Header (`.site-header`)
- **Variants:** transparent (over hero) / `.is-scrolled` (blurred bg). **States:** default, scrolled. **Responsive:** full nav ≥1025px; hamburger + hidden CTA ≤1024px. **RTL:** logo right, toggles left. **a11y:** `<header>`, sticky, skip-link precedes it.

## Desktop nav (`.main-nav__list`)
- Items: Home · About · Services▾ · Work · Journal · Clients · Contact. **States:** default, hover, `.is-active`+`aria-current`. **Content limit:** 7 items — Arabic labels are longer; nav gap tightens at 1080px. **a11y:** `<nav aria-label="Primary">`.

## Services dropdown (`.has-dropdown .dropdown`)
- Desktop hover/focus-within; mobile tap-accordion (`aria-expanded`). 4 items. **RTL:** opens aligned to inline-start.

## Mobile nav (`.main-nav.is-open` + `.nav-backdrop`)
- Slide-in panel `min(320px,84vw)`; scroll-locked; Esc/backdrop/link close. **RTL:** slides from inline-start. **Build:** focus trap + restore.

## Language switcher (`.lang-toggle`)
- Two pills AR/EN; active filled. Persists to localStorage; swaps lang/dir. **a11y:** `role="group"`, buttons.

## Buttons (`.btn`)
- **Variants:** `.btn--accent` (magenta fill, **dark text `#2a0148`**), `.btn--dark` (dark glass). **States:** default, hover (lift+glow), focus-visible, disabled, `.is-loading` (spinner). Radius 9px.

## Form controls (`.field`, `.field-row`, `.file-drop`, `select`)
- **States:** default, hover, focus (accent border), filled, required, invalid (`.has-error` + `.field-error`), disabled. `.field-row` = 2-col → 1-col ≤560px. **File drop:** default / `.has-file`. **a11y:** label+for, aria-live errors. **Build:** aria-invalid + describedby.

## Service cards (`.service-card`) — home teaser
- 4 cards, aspect 5/6, radius 29px, image + gradient overlay + label; hover lift/brighten. **Responsive:** 4→2→1 col.

## Service tabs (`.svc-tabs .svc-tab`) — services + service pages
- 2×2 glass tiles; one `.is-active` (the current service on detail pages; none on overview). Each has a main link + "Start your project" CTA. **Responsive:** reflow ≤520px.

## Portfolio cards (`.post-card[data-category]`) — portfolio archive
- Media (16/10 zoom-on-hover) + category + title (`<h2>`) + client line. **States:** default, hover lift, `.is-hidden` (filtered out). **Content:** category ∈ video/motion/design/web; client optional. **Grid:** 3→2→1 col.

## Project case-study blocks — project page
- Meta `<dl>` (Client/Year/Role/Deliverables), prose sections (Overview/Challenge/Approach/Solution/Result), gallery (`.work-card` → lightbox), related grid, prev/next, CTA. **Content limits:** title ≤~60 chars; deliverables short list.

## Client cards (`.corp-card`, `.indiv-card`)
- Corporate: equalizer tile `<button>`, aspect 3/2, hover lift+glow → lightbox. Individual: info + thumbnail + play, → lightbox/channel. **Build:** render tiles server-side.

## Blog cards (`.post-card`) — journal
- Media + category + title (`<h3>`) + excerpt + meta. 3→2→1 col.

## Pagination (`.pagination`)
- Prev / numbers / Next; `.is-current` highlighted, `.is-disabled` dimmed. **a11y:** `<nav aria-label>`, disabled = `<span>`, links have aria-label.

## Breadcrumbs (`.page-crumb`)
- Home / … / current. **RTL:** separators mirror. **a11y:** `<nav aria-label="Breadcrumb">`.

## Lightbox (`.lightbox`)
- Image / video / embed; gallery arrows + dots + counter; keyboard; scroll-lock. **Build:** dialog role + focus trap + restore + counter markup.

## Slider (hero `.hero`, clients tracks)
- Hero: dot tabs + auto-advance. Clients: arrow paging + drag. **Build:** hero prev/next/pause + live region.

## Legal TOC (`.legal-toc`)
- Sticky; scrollspy active link; 2-col → 1-col ≤900px.

## Footer (`.site-footer`, `.site-footer--flat`)
- Standard 3-col (contact / quick form / join) + bottom bar; flat 2-col on contact. **Responsive:** → 1 col ≤900px. `id="contact"`.

## Notifications / loading / empty / error states
- **Success:** `.form-success` (`role="status"`). **Loading:** button `.is-loading` spinner; `.preloader`. **Empty:** portfolio `#portfolioEmpty`, plus `journal.empty` / `search.empty` strings. **Error:** `.field-error`, form-level summary (build), `forms.serverError` / `forms.rateLimited`.

## Email shell
- 600px table, gradient header, dark card, violet summary box, footer; accent CTA dark-on-magenta. EN LTR + AR RTL. See `EMAIL_HANDOFF.md`.

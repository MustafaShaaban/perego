# Acceptance — GlobalMediaLightbox
## Visual
- [ ] Matches golden screenshot (automated diff within tolerance)
- [ ] Manual overlay review passed (EN + AR, desktop + mobile, tablet where flagged)
- [ ] Exact section order (per docs/pages manifest)
- [ ] Exact assets (no substitutions)
- [ ] Exact typography (sizes/weights/line-height; no different wrapping)
- [ ] Exact spacing (tokens match rendered)
- [ ] Exact responsive behaviour at documented breakpoints
- [ ] No horizontal overflow at 390 / 768 / 1024 / 1440

## Functional
- [ ] All links resolve to correct routes
- [ ] Navigate-vs-lightbox rules honoured (per §8.2)
- [ ] Exactly ONE instance, last child of body, z=3000 above all site chrome
- [ ] Opens ONLY from allow-listed triggers (§8.2)
- [ ] Image/video/gallery modes correct; aspect preserved; no overflow
- [ ] Esc/close/backdrop all close; prev/next/dots work; wraparound only if approved
- [ ] Focus moves in, is trapped, restored to trigger; background inert
- [ ] Video pauses on close/navigate; no autoplay-with-sound
- [ ] Loading + media-error states present; reduced-motion respected
- [ ] AR: controls mirror; keyboard follows media order; caption dir=auto

## CMS
- [ ] Required content editable; locked visuals stay locked
- [ ] Repeatable content from approved source; empty states work

## Accessibility
- [ ] Keyboard reachable + visible focus
- [ ] Screen-reader labels correct; RTL correct
- [ ] Reduced-motion respected; contrast AA

## Technical
- [ ] No console errors; no broken images/media
- [ ] Only one global lightbox instance; no invisible-open state
- [ ] No duplicate form submission

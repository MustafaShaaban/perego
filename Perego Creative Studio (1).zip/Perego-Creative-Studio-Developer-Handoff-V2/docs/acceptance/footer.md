# Acceptance — SiteFooter
## Visual
- [ ] Matches golden screenshot (automated diff within tolerance)
- [ ] Manual overlay review passed (EN + AR, desktop + mobile, tablet where flagged)
- [ ] Exact section order (per docs/pages manifest)
- [ ] Exact assets (no substitutions)
- [ ] Exact typography (sizes/weights/line-height; no different wrapping)
- [ ] Exact spacing (tokens match rendered)
- [ ] Exact responsive behaviour at documented breakpoints
- [ ] No horizontal overflow at 390 / 768 / 1024 / 1440

## Functional
- [ ] All links resolve to correct routes
- [ ] Navigate-vs-lightbox rules honoured (per §8.2)
- [ ] 3 variants (standard/flat/min) render correctly
- [ ] 3->1 col at 900; dividers switch axis
- [ ] Contact details exact; year generated

## CMS
- [ ] Required content editable; locked visuals stay locked
- [ ] Repeatable content from approved source; empty states work

## Accessibility
- [ ] Keyboard reachable + visible focus
- [ ] Screen-reader labels correct; RTL correct
- [ ] Reduced-motion respected; contrast AA

## Technical
- [ ] No console errors; no broken images/media
- [ ] Only one global lightbox instance; no invisible-open state
- [ ] No duplicate form submission

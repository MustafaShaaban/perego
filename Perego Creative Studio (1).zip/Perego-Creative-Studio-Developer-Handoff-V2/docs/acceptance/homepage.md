# Acceptance — Homepage
## Visual
- [ ] Matches golden screenshot (automated diff within tolerance)
- [ ] Manual overlay review passed (EN + AR, desktop + mobile, tablet where flagged)
- [ ] Exact section order (per docs/pages manifest)
- [ ] Exact assets (no substitutions)
- [ ] Exact typography (sizes/weights/line-height; no different wrapping)
- [ ] Exact spacing (tokens match rendered)
- [ ] Exact responsive behaviour at documented breakpoints
- [ ] No horizontal overflow at 390 / 768 / 1024 / 1440

## Functional
- [ ] All links resolve to correct routes
- [ ] Navigate-vs-lightbox rules honoured (per §8.2)
- [ ] Preloader shows once/session, never blocks, off under reduced-motion
- [ ] Hero rotates 3 slides @6.5s, pauses on hover/tab-hidden, dots work, one H1 only
- [ ] Service cards NAVIGATE (never lightbox)
- [ ] Corporate logos do NOT open lightbox (C-05)
- [ ] Individual card play+lightbox ONLY when media exists; no double-navigate (C-04)
- [ ] About panels + bg focal flip correctly in RTL

## CMS
- [ ] Required content editable; locked visuals stay locked
- [ ] Repeatable content from approved source; empty states work

## Accessibility
- [ ] Keyboard reachable + visible focus
- [ ] Screen-reader labels correct; RTL correct
- [ ] Reduced-motion respected; contrast AA

## Technical
- [ ] No console errors; no broken images/media
- [ ] Only one global lightbox instance; no invisible-open state
- [ ] No duplicate form submission

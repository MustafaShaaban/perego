# docs/acceptance/ — Acceptance checklists

A page/component is COMPLETE only when it passes Visual + Functional + CMS + Accessibility + Technical
gates AND its golden comparison passes automated diff and manual overlay (visual-regression-manifest.json).
Rendering without errors is not completion (HANDOFF_AUTHORITY §3).

Blockers — a page is NOT complete if: a required section is missing · order differs · asset substituted ·
decorative artwork differs · spacing materially differs · typography wraps differently · component
structurally different · mobile/Arabic/RTL unverified · lightbox placement/behaviour differs · media
opens when it should navigate (or vice-versa) · an upload control doesn't show the selected filename ·
remove/replace missing · CMS can't reproduce the visual · the baseline came from the implementation itself.

# Sections — Service pages (§14 / §15)  — Shared vs Unique matrix

Applies to the 4 service pages + the services overview. Do NOT derive one from another without this matrix.

## Shared (identical across all four service pages)
- svc-hero shell: min-height 92vh, centered, svc-hero-bg.png background + scrim, padding-top clamp(70,9vw,120).
- Eyebrow "Our Services" (14/600, .18em, uppercase, accent-soft) — present on the 4 service pages; ABSENT on overview.
- svc-tabs: 4 glass tiles, grid 4->2 (760/520), aspect 1/1, radius 20, hover/active magenta gradient + reveal CTA. The Services PARENT nav item is .is-active on every service page.
- whatwedo shell: 2-col grid (1fr/1fr, gap clamp(30,5vw,72)), H2 "What we do", subline accent-soft fs-h3, media radius 29 rotate(-1.2deg); <=900 -> 1col, media above, no rotate.
- process shell: gradient-process band, 4 steps + arrows, icon 56 (84 on tablet), label 17/700, desc 13 max22ch; <=620 stacks vertical with rotated arrows.
- Footer: standard. Header: overlay.

## Unique per service
| Property | Video Editing | 2D Motion Graphics | Graphic Design | Website Making |
|---|---|---|---|---|
| route | /services/video-editing | /services/motion-graphics | /services/graphic-design | /services/website-making |
| H1 | Video Editing & Post-Production | 2D Motion Graphics & Animation | Graphic Design & Brand Identity | Website Making |
| active tab | Video Editing | 2D Motion Graphics | Graphic Design | Website Making |
| whatwedo subline | Video Editing & Post-Production | 2D Motion Graphics & Animation | Graphic Design & Brand Identity | Website Making & Development |
| whatwedo media | ui-video-editing.png | ui-motion-graphics.png | ui-graphic-design.png | ui-graphic-design.png (reused — no ui-website asset; see image spec) |
| process step 1 | Footage Review (clapper) | Understanding the Idea (hands) | Brand Understanding (hands) | Discovery & Goals (hands) |
| process step 2 | Creative Editing (film-l) | Concept & Storyboard (pen) | Visual Direction (star) | Wireframe & Design (browser) |
| process step 3 | Effects & Refinement (star) | Animation & Design (star) | Design Execution (pen) | Build & Develop (laptop) |
| process step 4 | Delivery & Revisions (film-h) | Review & Delivery (film-h) | Review & Delivery (film-h) | Launch & Support (film-h) |
| selected work | work-masonry (filter video-editing) | work-masonry (motion) | work-masonry (graphic) | web-showcase filtered grid (UNIQUE component) |
| lightbox media | filtered to that service | filtered | filtered | web-card shot -> image lightbox; Visit -> external |

## Services overview differences
- H1 "Our Services" (no eyebrow). No tab active. whatwedo H2 "One studio, four services", subline "Video · Motion · Design · Web". process labels Discover/Concept/Create/Deliver. selected-work = masonry "Selected work". Adds a CTA band ("Have a project in mind?") that the 4 service pages do NOT have.

## Long-content behaviour
H1/sublines use clamp; long AR titles wrap to 2 lines (keep centered). whatwedo paragraphs may grow — panel has no fixed height. process desc capped 22ch; longer AR wraps to 3 lines, keep step alignment (align-items flex-start). Tabs labels wrap within tile.

# Section — Home Hero  (route / , id: hero)

## Purpose & meaning
First impression; communicates Perego's creative philosophy across 3 rotating statements. Visitor should
grasp "creative studio, ideas in motion" and reach the "Say Hello!" CTA. Highest page-hierarchy element;
precedes About. Full-viewport.

## Layout measurements (desktop 1440)
- Full width; content in .container (max 1440, gutter clamp(20,5vw,80)). content max-width 1180.
- Section min-height 100vh; margin-top -94px + padding-top 94px (RECONCILE to header 90px, C-09).
- Title fs-hero clamp(42,5.2vw,76), lh 1.02, letter-spacing -.01em. Text max 1150, margin-top 28, fs-lead.
- CTA margin-top 44. Dots absolute bottom 40, centered, gap 12. z-order: prism 0, ::after glow 1, content 2, dots 3.

## Background & decoration
- Base: radial-gradient(120% 90% at 70% 0%, #2a0850, #1a0338 40%, #0c0020 78%, #060010 100%).
- Layer prism: hero-bg.png full-bleed, object-fit cover, animation heroDrift 26s (scale 1.06->1.1 drift). Decorative, alt="".
- Layer glow: ::after radial rgba(199,125,255,.16) pulse 8s. pointer-events none.
- Reduced-motion: drift + pulse OFF.

## Typography
| Element | El | Font | Wt | Size | LH | Color |
| title | h1 (slide1) / p (slides 2-3) | Open Sans | 700 | clamp(42,5.2vw,76) | 1.02 | #fff |
| body | p.hero__text | Open Sans | 400 (strong 700) | fs-lead clamp(16,1.35vw,21) | 1.55 | rgba(255,255,255,.92) |
Arabic: Cairo; same sizes; expect ~+10% line-height comfort; long AR wraps — keep max-width.

## Responsive
- <=680px: min-height 92vh; title/text clamp down; CTA full-tap; dots stay bottom-centered.
- Tablet: no structural change (single column content already).

## RTL
Mirrors via logical props; text right-aligned start; dots centered (symmetric). Slide order unchanged; entrance heroIn same. Only ONE h1 (slide 1) — keep for AR too.

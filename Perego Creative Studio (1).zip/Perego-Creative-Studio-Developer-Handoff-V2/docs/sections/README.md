# docs/sections/ — Deep section specifications

Each file follows §6: purpose & meaning · approved visual references (crops/redlines) · exact layout
measurements · background & decoration (every layer, by asset filename) · typography (per element,
desktop/tablet/mobile + Arabic) · responsive (resulting layout, not just breakpoints) · RTL.
Values are the REAL ones from site/css/styles.css. Redline overlays live in redlines/ (see redlines/README.md).

Focus set (highest implementation risk): homepage sections + the service pages (§14/§15).
Shared editorial sections (post/prose/legal/blog) are specified in docs/components/ and page manifests.

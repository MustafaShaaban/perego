# Section — Home About  (id: about)

## Purpose & meaning
Introduce the agency + mission over an atmospheric figure. Two glass panels sit to one side of a portrait
background. Builds trust; bridges hero -> services.

## Layout measurements
- Section min-height 78vh; padding-block section-y clamp(52,6.5vw,100); bg #0c0020; overflow hidden.
- Inner grid: 1fr minmax(0,620px); panels in column 2 (RTL: column 1). Panel gap clamp(18,2.4vw,30).
- glass-panel: border 1px glass; radius 29; bg rgba(22,4,53,.55) + blur10; padding clamp(26,3vw,44); inset glow shadow.
- panel-title fs-h2/700 lh1.05 margin-bottom14; body fs-lead rgba(255,255,255,.92) text-align justify; p+p margin-top16.

## Background & decoration
- about-hooded.png full-bleed, object-fit cover, object-position 28% center (RTL 72% center). Decorative alt="".
- Scrim ::after: linear-gradient 90deg transparent->rgba(12,0,32,.94) (RTL 270deg). At <=900 becomes vertical (180deg) scrim.

## Typography
h2.panel-title fs-h2 clamp(28,3vw,40)/700; p fs-lead/400 justify. Arabic Cairo; justify may loosen — consider text-align start for AR if rivers appear (document as suggested).

## Responsive
<=900px: grid 1 col; panels full width; bg scrim vertical; min-height auto. Panels stack (About then Mission).

## RTL
Panels move to column 1 (left); bg focal + scrim flip to mirror. Reveal animation identical.

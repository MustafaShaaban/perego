# Section — Services Teaser  (id: services)

## Purpose & meaning
Preview the 4 services and route to them. Cards NAVIGATE to service pages (never lightbox, §15).

## Layout measurements
- padding-block section-y; bg gradient-page + wavy-corners overlay (img opacity .6). z: bg 0, inner 2.
- head max-width 560 (title fs-h1 lh1.05 + "See All Services" link-arrow margin-top 26 -> services.html).
- .service-cards grid repeat(4,1fr); gap clamp(18,2vw,34); margin-top clamp(30,4vw,10); align-items start.
- Card aspect 5/6; radius 29; shadow 0 24px 60px rgba(0,0,0,.45). Stagger: nth-2 margin-top clamp(40,7vw,120); nth-4 clamp(60,10vw,170); nth-1/3 = 0.
- Overlay gradient bottom-darken; label bottom padding 22 24, clamp(18,1.5vw,24)/700 uppercase, text-align start.
- Hover: translateY(-10), bigger shadow, inset 2px accent ring + glow.

## Background & decoration
gradient-page base; wavy-corners.png overlay (decorative). Card images card-*.png (content, alt=service).

## Typography
h2.services-teaser__title fs-h1; label clamp(18,1.5vw,24)/700 uppercase #fff. Arabic Cairo; 2-line labels (Video/Editing) keep <br> or allow wrap.

## Responsive
<=680: 2 cols; stagger reduced (nth-2/4 = 34px). <=440: 1 col; stagger removed; card aspect 16/10.

## RTL
Grid + stagger mirror; label text-align start (=right). link-arrow svg flips.

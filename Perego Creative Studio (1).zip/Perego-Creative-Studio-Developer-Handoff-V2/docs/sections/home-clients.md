# Section — Clients (Corporate + Individual)  (id: clients)

## Purpose & meaning
Social proof: two sliders — corporate logos (2-row) and individual clients (showreels). See CONFLICTS C-04/C-05 for interaction rules.

## Layout measurements
- padding-block section-y; bg bg-deep; wavy-corners overlay. Two heads (section-title fs-h1 + subtitle fs-lead muted); individual head margin-top clamp(48,6vw,88).
- Corporate: 2-row column-flow grid; per-row count 10/8/6/4/3 by breakpoint; gap clamp(10,1vw,16); scroll-snap; padding 26 8. Card aspect 3/2 radius 16 violet gradient, icon 44% width. Arrows 44 circle; edge fades 90px.
- Individual: column-flow grid; 3/2/1 per view (960/620); gap clamp(16,2vw,26); scroll-snap mandatory. Card grid 1fr/42%, min-height 150, radius 18. play-btn 54 circle accent + ring.

## Background & decoration
bg-deep + wavy-corners.png (decorative). corp-icon.png (PLACEHOLDER logo), client-review-crop.png (PLACEHOLDER thumb).

## Typography
h2.section-title fs-h1; subtitle fs-lead muted; indiv title clamp(18,1.5vw,22)/700, sub 13, stat 15.

## Responsive
Corporate per-row: 10@>1080 /8@1080 /6@820 /4@560 /3@400. Individual: 3 ->2@960 ->1@620.

## RTL
Both tracks + arrows + edge fades mirror (logical props). Scroll direction reverses. Digits per site convention.

## Interaction (must follow §8.2)
Corporate tiles: NO lightbox by default (C-05). Individual cards: lightbox only if media exists, via play-btn, no double-navigate (C-04).

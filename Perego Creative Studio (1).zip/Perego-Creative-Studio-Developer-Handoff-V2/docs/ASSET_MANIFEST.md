# Asset Manifest

Assets live in `site/assets/images/` (optimized previews) and `source/` (originals — do **not** serve directly). For each production asset: convert to **WebP/AVIF** with a PNG/JPG fallback, set explicit `width`/`height`, and lazy-load everything below the fold. The LCP image is the **home hero** (`hero-bg.png`) — preload it and mark `fetchpriority="high"`; do not lazy-load it.

## Decorative vs content
- **Decorative → `alt=""`, `aria-hidden`, lazy:** `hero-bg`, `svc-hero-bg`, `svc-banner-bg`, `services-hero`, `about-hooded` (background use), `wavy-corners`, `brand-card-bg`, `brand-wordmark`, `brand-card-mark`, `corp-icon`, `footer`, all `icon-*`, the watermark logo on contact.
- **Content → descriptive `alt`:** `logo-full` (alt "Perego بيريجو"), `portfolio-*` (name the project + service), `card-*` (service name), `ui-*` (software UI), `client-review-crop`.

## Manifest

| File | Purpose | Dimensions | Aspect | Alpha | Desktop use | Mobile use | Decorative | WP behaviour | Notes |
|---|---|---|---|---|---|---|---|---|---|
| `logo-full.png` | Primary logo (header/footer/preloader/email) | 552×170 | ~3.25:1 | yes | header 46px tall | ~40px | no | SVG preferred | Provide an SVG master; ship 1×/2× PNG fallback |
| `hero-bg.png` | Home hero prism bg (**LCP**) | 1920×1080 | 16:9 | no | full-bleed | full-bleed, focal center | yes | preload, no-lazy | AVIF+WebP; art-direct a taller crop for portrait phones |
| `svc-hero-bg.png` | Services/service hero bg | 1920×1108 | ~16:9 | no | full-bleed top | full-bleed | yes | lazy | focal top-center (face) |
| `svc-banner-bg.png` | Service banner gradient | — | wide | no | banner | banner | yes | lazy | |
| `services-hero.png` | Services overview hero | — | wide | no | full-bleed | full-bleed | yes | lazy | |
| `about-hooded.png` | About/contact hero figure | 1600×900 | 16:9 | no | split/bg | bg | yes | lazy | focal on figure |
| `wavy-corners.png` | Decorative neon line bg | 1800×1013 | ~16:9 | yes | section bg | hide/scale | yes | lazy | can be CSS/SVG instead |
| `brand-card-bg.png` | Works "brand card" bg | 361×1387 | tall 1:3.8 | no | portrait tile | portrait tile | yes | lazy | vertical wordmark tile |
| `brand-wordmark.png` | Rotated "Perego بيريجو" | — | tall | yes | brand card | brand card | yes | lazy | rotated -90° |
| `brand-card-mark.png` | Pink logo mark | — | ~1:1 | yes | brand card | brand card | yes | lazy | |
| `corp-icon.png` | Corporate-client glyph | 178×179 | 1:1 | yes | tile | tile | yes | lazy | placeholder for real client logos |
| `card-video-editing.png` etc. (×4) | Service teaser card art | 560×680 | 5:6 | no | 4-up grid | 1-up | no | responsive srcset | one per service |
| `ui-video-editing.png` etc. (×3) | "What we do" software UI | 2341×1667 | ~7:5 | no | half | full | no | responsive srcset | large — downscale/compress hard |
| `portfolio-1…9.png` | Portfolio/journal thumbnails | 640×400 | 16:10 | no | grid | grid | no | responsive srcset | **PLACEHOLDER — replace with real work** |
| `client-review-crop.png` | Individual-client thumb | — | 16:9 | no | card | card | no | lazy | placeholder |
| `icon-*.png` (clapper, film-h/l, star, pen, laptop, browser, hands) | Process/step glyphs | small | 1:1 | yes | inline | inline | yes | inline/sprite | `alt=""`; prefer an SVG sprite |
| `service-*.svg` (×4) | Service vector art | vector | — | yes | — | — | yes | inline SVG | editable source vectors |
| `footer.png` | Footer texture | — | wide | yes | footer bg | footer bg | yes | lazy | low priority |

## Production guidance
- Generate `srcset`/`sizes` for `card-*`, `ui-*`, `portfolio-*`, and hero images (320/640/960/1280/1920 widths).
- Prefer **SVG** for `logo-full`, `corp-icon`, `icon-*`, and social icons (social icons are already inline SVG in the footer sprite).
- Compress `ui-*` (currently 2341px) aggressively — they render at ≤700px.
- Replace all `portfolio-*` and `client-review-crop` with real, rights-cleared media; update the lightbox `pool` array in `main.js` with real client media URLs.
- Keep originals/large artboards in `source/` only — never reference them from production markup.

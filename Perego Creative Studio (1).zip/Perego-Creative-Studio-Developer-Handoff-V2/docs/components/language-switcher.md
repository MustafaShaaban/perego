# Component — LanguageSwitcher

Purpose: toggle EN(LTR)/AR(RTL). DOM: .lang-toggle[role=group aria-label=Language] > 2× button.lang-toggle__btn[data-lang].
State mechanism: `.is-active` on the current button; applies document.documentElement.lang + dir, body.lang-ar; persists localStorage['perego-lang']; re-applies on load.
Measurements: btn min-width 46px; padding 10px 14px; radius 10; 15px/700; inactive bg rgba(72,3,131,0.55); active bg accent + glow shadow.

| Current | Event | Next | Visual | Functional |
|---|---|---|---|---|
| EN active | click AR | AR active | AR btn accent+glow; whole doc mirrors to RTL, font->Cairo | lang=ar, dir=rtl, body.lang-ar, saved |
| AR active | click EN | EN active | EN btn accent | lang=en, dir=ltr, saved |
| any | focus-visible | — | 2px accent outline offset 3 | — |

RTL: the toggle itself mirrors; content re-typesets to Cairo. Numbers/punctuation follow CSS logical props. A11y: buttons are real buttons; active reflected visually + should set aria-pressed. Acceptance: persists across reload + across pages (localStorage); focus visible.

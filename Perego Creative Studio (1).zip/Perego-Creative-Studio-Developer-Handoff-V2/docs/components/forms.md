# Component — Form controls (text / email / url / tel / textarea / select / choice)

DOM: .field [ label | input|textarea|select ] (+ .field-error, + .field-counter for capped textareas).
State mechanism: `.has-error` on .field; aria-invalid on control; live counter .field-counter(.is-limit).
Controls: transparent bg; input/select = bottom border 1.5px rgba(216,106,243,.5), radius 0; textarea = full
1.5px border, radius 12, min-height 96, resize vertical; font 15px; focus => border-color accent, outline none.
Select has custom caret SVG; options bg #1a0338. Placeholder color rgba(255,255,255,.42).

Validation (main.js forms()): required, email/url/tel regex, min/maxlength; default caps by name
(name80 email120 phone24 company80 subject120 portfolio200 message1200); textareas get live counter.
Validate on blur + on input (once errored) + on change (file). On submit: validate all; focus first error;
else button .is-loading, disabled, simulate 1.4s, reset, show .form-success (role=status) 6s.

| State | Trigger | Visual |
|---|---|---|
| default | — | underline/border rgba accent .5 |
| hover | pointer | (inherits; document if distinct) |
| focus | focus | border accent |
| filled | value present | text #fff |
| error | invalid on blur/submit | .has-error red border #ff6ba6; .field-error text #ff9ad1 |
| counter limit | length>=max | .field-counter.is-limit pink |
| submitting | submit valid | button spinner, disabled |
| success | after submit | .form-success green pill |

Contact choose-service (.svc-choice): toggle buttons, multi-select, aria-pressed, write hidden input[name=services]; ?service= preselect.
RTL: labels/controls mirror; error text alignment follows dir; counter inset-inline-end. A11y: label[for]/id;
aria-invalid; aria-live errors + counter aria-hidden; success role=status. See file-uploader.md for CV field.

# Component — FileUploader

Replaces the minimal `.file-drop` (which only swaps its label to the filename). V2 mandates a complete uploader with a persistent selected-file row, formatted size, status, Remove/Replace, per-select validation, long-filename handling, and validation persistence. Used in **every form with an upload**: the footer "Join us" form (field `cv`) and any careers/project-brief form. Prototype code is **not** modified this pass (CONFLICTS C-07); this is the build target 🔁.

Class: Locked visual (chrome) · Functional (validation/state) · CMS/config (accept, max size, count).
Tokens: `file-upload-*` in design-tokens.v2.json.

---

## 1. Anatomy
    .file-uploader (role region, labelled by field label)
      label.file-drop (the drop zone / trigger; min-height 48px; radius 10; dashed border default)
        upload icon
        .file-drop__text  ("Upload your CV here" / drag instruction)
        (hint line)      "PDF, DOC or DOCX · max 10 MB · 1 file"
        input[type=file] (visually hidden but real; accept=".pdf,.doc,.docx")
      .file-row  (appears AFTER a valid selection; hidden by default)
        file-type icon
        .file-row__name   (original filename, ellipsis-truncated; title=full name)
        .file-row__meta   ("PDF · 2.4 MB")
        .file-row__status ("Ready to upload" | "Selected" | "Uploading…" | "Uploaded" | "Rejected")
        button.file-row__remove  ("Remove", ≥44px target)
        (button.file-row__replace "Replace" — where approved)
      .field-error  (aria-live polite; per-file validation message)

## 2. States & state mechanism
State on the uploader via `data-state`; JS and CSS share this contract:
`data-state="default | selected | uploading | uploaded | rejected"` plus `.file-drop.has-file` for the drop-zone visual (solid accent border when a file is attached).

| State | Trigger | Visual | Data/functional |
|---|---|---|---|
| default | initial / after Remove | dashed border, muted text, no file-row | input value empty |
| selected | valid file chosen | solid accent border; file-row shows name+meta; status "Ready to upload" | input holds File; form may submit |
| rejected | invalid file chosen | error border; field-error message; file-row may show name with status "Rejected" | input cleared or flagged invalid; blocks submit |
| uploading | async upload in progress (if async) | progress indicator; status "Uploading… 60%" | disable duplicate submit |
| uploaded | server confirms (async) OR form submit success | status "Uploaded"; success tint | show only after server confirmation |

**Non-async (default for these forms):** show filename immediately on select → status "Selected/Ready to upload" → keep through validation → clear only on whole-form reset after successful submit. **Never** show "Uploaded successfully" before the server confirms.

## 3. Filename display (mandatory)
Immediately after a valid selection show the **original filename**, extension, and **formatted size** (e.g. `project-brief.pdf` · `PDF · 2.4 MB` · `Ready to upload`) with Remove (and Replace where approved). Never keep showing only "No file chosen."

**Long filenames:** truncate visually with ellipsis (CSS `text-overflow: ellipsis` on `.file-row__name`, single line); **never** alter the real filename; expose the full name via `title` + visually-hidden text for screen readers; keep the extension legible where possible (truncate the middle if needed).

## 4. Validation (per-select, not submit-only)
Validate on `change`:
- Unsupported type → "This file type is not supported. Upload PDF, DOC or DOCX."
- Too large (>10 MB) → "This file is larger than the 10 MB limit."
- Too many files → "Only one file can be uploaded."
- Empty/corrupt (0 bytes) → "This file appears to be empty. Choose another."
- (async) interruption / server rejection / security fail → specific message + retry.
An invalid file is **never** shown as successfully selected. Messages state reason + allowed requirement. Provide approved Arabic translations (see docs/CMS_VISUAL_CONTENT_MAP.md / content/ar.json — add `forms.file.*` keys).

## 5. Remove & Replace
Remove must: clear input value; remove `.file-row`; clear that file's validation; restore default drop zone; allow re-selecting the **same** file afterwards (reset the input so the same-name `change` fires). Single-file: choosing another file replaces the previous and updates the row immediately. Multi-file (only where approved): one row per file, individual Remove, documented max count + total-size limit.

## 6. Validation persistence
If **another** field errors on submit, keep the valid selected file attached and its filename visible — do not force re-selection. If a browser/security limit makes preservation impossible, state that clearly in the UI and here in the spec. (HTML `<input type=file>` retains its FileList across a client-side submit attempt, so preservation is achievable for these client-validated forms.)

## 7. Submission & reset
On submit: disable duplicate submissions (button `is-loading`, disabled); keep filename visible; show progress if async. On success: show success state where the form remains; reset the uploader only when the whole form resets. On failure: preserve the file where possible, keep filename, show error, allow retry. Never silently drop the filename before success is communicated. (Prototype `forms()` resets `.file-drop` text back to "Upload your CV here" on the simulated success — the CoreX build should reset only after real server success.)

## 8. Accessibility
Real `<input type=file>`; keyboard-operable (label is focusable trigger; Remove/Replace are real buttons); label programmatically associated (`for`/`id`); announce selected filename and validation errors (`aria-live="polite"`, `aria-invalid`); expose accepted types + size limit in visible hint AND `aria-describedby`; Remove/Replace have accessible names; never rely on color alone (icon + text + border); visible focus ring (`focus-ring` token); RTL correct (logical props; row mirrors, ellipsis on the correct edge); mobile touch targets ≥44px.

## 9. Responsive & RTL
- Desktop: drop zone full width of the field; file-row is a single horizontal row (icon · name(flex) · meta · status · Remove).
- Mobile: row may wrap — name on line 1 (ellipsis), meta+status line 2, Remove right-aligned; keep 44px targets; long Arabic filenames wrap/truncate with full name in `title`; mixed AR/EN filenames use `dir="auto"` on `.file-row__name`.

Golden screenshots (required): `upload-default-desktop`, `upload-selected-desktop`, `upload-error-desktop`, `upload-uploading-desktop`, `upload-success-desktop`, `upload-default-mobile`, `upload-selected-mobile`, `upload-error-mobile`, `upload-ar-selected-desktop`, `upload-ar-selected-mobile`.

## 10. CMS / config & email
Per form document: accepted types, max size, max count, storage behaviour, admin visibility, filename preservation, security validation, retention. Emails that reference an uploaded file must preserve and display the **original filename** (see docs/EMAIL_HANDOFF and CMS map). Do not rename the file in user-facing email copy without also showing the original name.

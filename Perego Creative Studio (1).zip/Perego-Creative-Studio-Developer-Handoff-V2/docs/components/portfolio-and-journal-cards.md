# Component — PortfolioCard & JournalCard (post-card)

Shared .post-card used in work archive, journal archive, related, search results.
DOM: a.post-card[data-category]? > .post-card__media(img) + .post-card__body( .post-card__cat + h3.post-card__title + p.post-card__excerpt + .post-card__meta ).
IMPORTANT (§8.2): the card is an <a> that NAVIGATES (project page / article). It does NOT open the lightbox. If a separate media affordance is approved, it is a distinct control, not the card link.
Measurements: radius 16; bg #160435; border rgba(216,106,243,.18); shadow card. hover translateY(-6), shadow, border .45, image scale1.06. media aspect 16/10. body padding 20, gap 10. cat 12/700 uppercase accent-soft; title 19/700; excerpt 14 muted; meta 12.5 muted-2.
Grid: blog-grid 3col -> 2 (<=900) -> 1 (<=640).
RTL: mirrors; text-align follows dir. A11y: whole card link with descriptive text; images have real alt (project+service). CMS: repeatable from projects/posts CPT. Empty: category with 0 => handled by EmptyState. Assets: portfolio-*.png PLACEHOLDER.

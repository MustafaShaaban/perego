# Component — ServiceProcess

Purpose: 4-step horizontal process on a bright gradient band.
DOM: section.process > .container [ h2.section-title | ol.process-list ( 4× li.process-step + li.process-arrow between ) ].
Each step: span.process-step__icon(img) + label + desc.
Measurements: bg gradient-process (#1f0748->#b473ee); padding-block clamp(52,7vw,96). title centered, margin-bottom clamp(34,4.5vw,56).
process-list flex, justify space-between, nowrap. step flex-col center, flex 1, max-width 240, text-center.
icon 56×56 (img contain, drop-shadow accent), hover translateY(-6) scale1.05. label 17/700; desc 13/1.5 muted max 22ch.
arrow: chevron svg 26×26, color rgba(255,255,255,.8), padding-top 16.
Responsive: <=900 gap 6, step width 128, icon 84 (img 44). <=620 list stacks vertical, arrows rotate 90deg. reduced-motion: no icon hover animation dependency.
RTL: arrow glyphs scaleX(-1); when stacked (<=620) arrows are rotate(90) in both dirs (RTL rule resets scaleX).
Content UNIQUE per service (labels/desc/icons) — see docs/sections/service-pages.md matrix. Icons: clapper, film-l, film-h, star, hands, pen, laptop, browser (all decorative alt="").

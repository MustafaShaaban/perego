# Component — ServicesDropdown

Purpose: reveal the 4 service pages under the "Services" nav item.
DOM: li.has-dropdown > a.main-nav__link[aria-haspopup=true][aria-expanded] (+ svg.nav-caret) > ul.dropdown > 4× li>a.
State mechanism: DESKTOP = hover/focus-within (`:hover, :focus-within`) reveal; MOBILE(<=1024) = click toggles `.is-open` on li.has-dropdown + aria-expanded on the link (JS preventDefault the parent link).

Measurements: dropdown position absolute; inset-inline-start:0; top calc(100% + 14px); min-width 230px;
padding 8px; radius 14; bg rgba(22,3,47,0.97) + blur(14); border glass; shadow 0 24px 60px rgba(0,0,0,.5);
z {z.dropdown}=1050. Hidden = opacity0/visibility hidden/translateY(8px); open = opacity1/visible/translateY(0), 0.22s.
Items: a padding 11px 14px; radius 9; 15px/600; hover bg accent, color #fff. Caret rotates 180deg when open.
Mobile: dropdown becomes static, indented (padding-inline-start 12px), max-height 0 -> 320px transition.

| Current | Event | Next | Visual | Functional |
|---|---|---|---|---|
| Closed | pointer enter / focus (desktop) | Open | fade+rise in | items focusable |
| Open | pointer leave / blur (desktop) | Closed | fade+drop out | — |
| Closed | parent link click (mobile) | Open | .is-open, caret 180, max-height expand | aria-expanded true; parent link does NOT navigate |
| Open | parent link click (mobile) | Closed | collapse | aria-expanded false |
| any | Esc | Closed | — | (mobile nav also closes) |

RTL: opens from inset-inline-start (=right in RTL); caret unchanged. A11y: aria-haspopup, aria-expanded synced; items are real links. CMS: service list = the 4 fixed services. Acceptance: hover(desktop)+click(mobile) both work; state contract shared; keyboard reachable.

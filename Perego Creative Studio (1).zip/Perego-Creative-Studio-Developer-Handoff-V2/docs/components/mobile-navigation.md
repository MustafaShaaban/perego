# Component — MobileNavigation

Purpose: nav on <=1024px via slide-in panel.
DOM: button.nav-toggle#navToggle (hamburger, 46×46) toggles nav.main-nav#mainNav (panel) + .nav-backdrop.
State mechanism: `.is-open` on #navToggle, #mainNav, #navBackdrop; body gets `.nav-locked` (scroll lock, preserves scrollY via body top offset).

Measurements: panel position fixed; inset-block 0; inset-inline-end 0 (RTL: start); width min(320px,84vw);
padding 90px 30px 30px; bg #16032f; border-inline-start 1px glass; shadow -20px 0 60px rgba(0,0,0,.5);
transform translateX(100%) -> 0 (RTL translateX(-100%)); transition 0.32s. Backdrop: fixed inset0;
z {z.navBackdrop}=1100; panel z {z.navPanel}=1200; bg rgba(6,0,16,0.25). Links: block, padding 12px 0, 18px.
Hamburger -> X: .is-open rotates the two bars (translateY ±7 rotate ±45), middle bar transparent.

| Current | Event | Next | Visual | Functional |
|---|---|---|---|---|
| Closed | toggle click | Open | hamburger->X; panel slides in; backdrop fades | aria-expanded true; body scroll locked; focus stays actionable |
| Open | toggle / backdrop click / Esc | Closed | panel slides out; X->hamburger | scroll unlocked; scroll position restored |
| Open | tap a nav link (not Services parent) | Closed | closes | navigates |
| Open | tap Services parent | Open | submenu toggles (see dropdown) | does not close nav |

RTL: panel enters from the left; border on inline-start. A11y: aria-controls, aria-expanded; Esc closes; focus order; backdrop click closes. Acceptance: lock/restore scroll; RTL side; Services submenu opens within.

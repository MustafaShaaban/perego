# Component — ServiceHero + ServiceTabs (+ ServiceCapabilities)

## ServiceHero
DOM: section.svc-hero > .svc-hero__bg(img svc-hero-bg.png) + .container.svc-hero__inner [ p.svc-hero__eyebrow? | h1.svc-hero__title | nav.svc-tabs ].
Measurements: min-height 92vh; centered; padding-bottom clamp(48,6vw,90); bg #0c0020; svc-hero__inner padding-top clamp(70,9vw,120).
bg img object-fit cover, object-position center top, opacity .95; scrim gradient to rgba(12,0,32,.9) bottom.
Title fs-hero/700/lh1.02, text-shadow 0 4px 40 rgba(0,0,0,.5). Eyebrow (service pages only, NOT overview): 14px/600, letter-spacing .18em, uppercase, accent-soft.
Variants: overview (H1 "Our Services", no eyebrow, no active tab) vs the 4 service pages (eyebrow + unique H1 + own tab active).

## ServiceTabs (shared, 4 tiles)
DOM: nav.svc-tabs[aria-label=Services] > 4× .svc-tab[.is-active?] > a.svc-tab__main(span.svc-tab__label) + a.svc-tab__cta.
State mechanism: `.is-active` on the current service's tile (main link aria-current=page). Hover === active visual.
Measurements: grid 4 cols, gap clamp(16,1.8vw,26), max-width 1120 centered, margin-top clamp(40,6vw,76).
Tile aspect 1/1; radius 20; glass bg rgba(34,12,58,.55) + blur14; border rgba(255,255,255,.22). Label clamp(15,1.3vw,21)/700 uppercase.
CTA hidden (max-height0/opacity0) -> reveals on hover/active (max-height60, padding 15px 12px). Hover/active: magenta gradient bg, translateY(-6), label+cta color #2a0148.
Tabs NAVIGATE to service pages / CTA -> contact.html?service=... They do NOT open the lightbox.
Responsive: 4->2 cols at 760px (max-width 520), stays 2 at 520px. RTL: grid mirrors; CTA arrow scaleX(-1).

## ServiceCapabilities (What we do)
DOM: section.whatwedo.page-section > .container.whatwedo__grid [ .whatwedo__text(h2 + subline + 2 p) | .whatwedo__media(img) ].
Measurements: grid 1fr/1fr, gap clamp(30,5vw,72), align center; bg gradient #160435->#10002b + wavy-corners overlay .5.
H2 section-title; subline accent-soft 700 fs-h3; p muted fs-lead. media radius 29, shadow, rotate(-1.2deg).
Responsive <=900px: 1 col, media order -1 (above text), rotation removed. Content is UNIQUE per service (see docs/sections/service-pages.md).

# Component — IndividualClientCard (+ individual slider)

Purpose: featured individual client with optional showreel. DOM: .indiv-slider > arrows + .indiv-track#individualTrack ( .indiv-card ... ).
CONFLICTS C-04 (must fix in build): a card opens the global lightbox ONLY when it has approved media, via a visible PLAY affordance. It must NOT ALSO navigate. Cards without media are non-interactive (no play button rendered). Remove the current href=youtube.com + target=_blank pattern.
DOM per card: .indiv-card > .indiv-card__info( h3 title + sub + stat ) + .indiv-card__thumb( img + span.play-btn[if media] ).
Measurements: card grid 1fr/42%; min-height 150; radius 18; violet gradient; hover lift -6 + shadow. info padding 20 22. title clamp(18,1.5vw,22)/700; sub 13 rgba .8; stat 15 (strong). thumb img cover; hover scrim rgba(12,0,32,.28). play-btn: 54 circle accent + 8px ring; centered; triangle ::before; hover scale1.12.
Slider: 3 per view -> 2 (<=960) -> 1 (<=620); scroll-snap mandatory; arrows reuse corp-arrow.
State mechanism: presence of play-btn = conditional on media URL. Interactive card => role/button semantics opening lightbox (video/embed).
RTL: mirrors; arrows flip. A11y: if interactive, use <button> with aria-label incl client name; play-btn aria-hidden decorative. CMS: repeatable; media URL optional -> controls play-btn + interactivity. Asset: client-review-crop.png PLACEHOLDER. Acceptance: play only when media; opens lightbox; no double-action; non-media card inert.

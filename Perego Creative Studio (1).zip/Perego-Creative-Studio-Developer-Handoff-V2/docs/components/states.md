# Component — Shared states (Empty / Loading / Success / Error / Disabled)

Empty state: centered muted message at fs-lead, padding clamp(40,6vw,80) 0. Used by portfolio filter (#portfolioEmpty), search no-results. Must render when a repeatable collection yields 0 items.
Loading: button spinner (.is-loading, 18px, plSpin .7s) for form submit; lightbox loading spinner (🔁) for slow media; skeleton not used.
Success: .form-success green pill (role=status, check icon + message), shown after submit, auto-hides 6s.
Error (form): .field.has-error red border #ff6ba6 + .field-error #ff9ad1 (aria-live). Server error 🔁: form-level message with retry.
Error (media): lightbox designed error state 🔁.
Disabled: buttons [disabled] non-interactive + dimmed; pagination .is-disabled; arrows [disabled] hidden/inert.
All states: not color-only (icon+text), visible focus preserved, announced to AT. Reduced-motion: spinners may remain (functional) but decorative pulses off.

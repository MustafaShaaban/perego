# Component — Buttons & link-arrow

.btn: inline-flex; gap 10; font-weight 700; 17px; letter-spacing .04em; uppercase; border 0; radius 9;
padding 16px 34px; transition transform/shadow/bg .25s.
- .btn--accent: bg accent, color #2a0148 (ink-on-accent, AA). Hover: translateY(-2), glow shadow.
- .btn--dark: bg #100016, color #fff. Hover: translateY(-2), shadow + 1px accent ring.
- Loading: `.is-loading` => color transparent + centered 18px spinner (::after, plSpin .7s); pointer-events none; disabled.
- Disabled: [disabled] => reduce opacity / no hover lift (document explicit disabled token if used).
link-arrow: inline-flex gap 10; 700; size fs-h3; arrow svg translateX(6) on hover; RTL flips svg (scaleX-1) and hover moves -6.

States table:
| State | Visual |
|---|---|
| default | filled accent / dark |
| hover | lift -2px + glow |
| focus-visible | 2px accent outline offset 3 |
| loading | transparent label + spinner, disabled |
| disabled | non-interactive, dimmed |

RTL: arrow icons mirror. A11y: real <button>/<a>; loading sets disabled; label text stays for AT (spinner is decorative). Tokens: button-* in v2 tokens.

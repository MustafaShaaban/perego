# Component — PortfolioFilters + EmptyState

DOM: .portfolio-filters[role=group] > buttons .web-filter.portfolio-filter[data-filter][aria-pressed]; grid #portfolioGrid; p#portfolioEmpty[hidden].
State mechanism: active pill `.is-active` + aria-pressed=true; cards toggle `.is-hidden`; when shown count===0 => #portfolioEmpty unhidden.
Pill: padding 10px 22px; radius 999; border rgba(216,106,243,.32); bg rgba(72,3,131,.22); 14/600. hover: border accent, translateY(-2). active: bg accent, color #12012e.
Filters: all/video/motion/design/web. Empty text: "No projects in this category yet. Try another filter."

| Current | Event | Next | Visual | Functional |
|---|---|---|---|---|
| filter A active | click filter B | B active | A loses is-active/pressed, B gains | grid filters by data-category; empty shown if 0 |

RTL: pills mirror; wrap unchanged. A11y: role=group, aria-pressed, aria-label. Acceptance: only one active; empty-state toggles; keyboard operable.

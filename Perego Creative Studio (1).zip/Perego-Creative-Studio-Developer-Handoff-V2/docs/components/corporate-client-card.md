# Component — CorporateClientCard (+ corporate slider)

Purpose: show corporate client logos. DOM (generated): .corp-slider > arrows + .corp-track#corporateTrack ( .corp-card ... ).
CONFLICTS C-05: default = NON-INTERACTIVE logo tiles. Corporate logos MUST NOT open a lightbox unless Perego explicitly approves. Current prototype generates data-gallery tiles that open placeholder media — DISABLE this until approved.
Measurements: track = grid, auto-flow column, 2 rows, per-row count var (10 desktop ->8@1080 ->6@820 ->4@560 ->3@400), gap clamp(10,1vw,16), horizontal scroll snap, no scrollbar, padding 26px 8px.
corp-card: aspect 3/2; radius 16; violet gradient; border rgba(216,106,243,.22); logo/icon centered (44% width). hover (IF interactive): lift -6, brighter gradient, glow. Edge fades (::before/::after) + arrows (44 circle) appear when scrollable; disabled at ends. Drag-to-scroll supported.
State: slider `.at-start`/`.at-end` toggle edge fades + arrow disabled.
RTL: track + edge fades + arrow glyphs mirror. A11y: track tabindex 0, role=group aria-label; arrows labelled. CMS: repeatable client logos; replace corp-icon.png placeholder with real logos + alt=company name. Acceptance: NO lightbox by default; arrows/edge-fades correct; RTL mirror.

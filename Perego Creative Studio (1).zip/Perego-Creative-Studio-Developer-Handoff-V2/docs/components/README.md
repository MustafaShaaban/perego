# docs/components/ — Reusable component specifications

Each file follows: purpose · anatomy/DOM · variants · interaction states (+ state-transition table
for interactive ones) · desktop/tablet/mobile measurements · RTL · accessibility · CMS source ·
empty/fallback · exact assets · acceptance. All measurements are the REAL values from
site/css/styles.css. State mechanism is named per component (.is-open / [hidden] / .is-active /
aria-expanded / data-state) and CSS+JS must share it.

Deep specs of note: global-media-lightbox.md, file-uploader.md.
Index: site-header, services-dropdown, mobile-navigation, language-switcher, buttons, forms,
home-hero, service-hero-and-tabs, service-process, selected-work-gallery, portfolio-filters,
portfolio-and-journal-cards, corporate-client-card, individual-client-card, pagination-breadcrumbs,
site-footer, preloader, states.

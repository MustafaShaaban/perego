# Component — SiteFooter

DOM: footer.site-footer#contact > [inline social sprite] + .container.site-footer__grid (3 cols) + .container.site-footer__bottom.
Col1 .footer-contact: logo + "Contact us" + 4 contact links (2 email,2 phone) + blurb + 5 social. Col2: contact form (name/email/message/Send). Col3: "Join us" blurb + form (name/portfolio url/CV file-drop/Apply now).
Variants: standard (footer.png texture via ::before) · flat (.site-footer--flat: solid gradient #1a0338->#2c0958, no texture, 2col >=901) · min (.site-footer--min bottom-only).
Measurements: grid 3col, padding-block clamp(48,6vw,82); footer-col padding-inline clamp(22,3vw,48); dividers = border-inline-start rgba(255,255,255,.14). heading fs-h3/700. contacts gap 9, each with 9px accent square marker. social 38×38 accent squares (radius 9), hover -> white bg / violet icon + lift. bottom: hairline top, 13px muted, copyright + legal links.
Responsive <=900: 1 col; dividers become block-start borders (padding-block-start 32); bottom centers <=560.
RTL: full mirror; dividers on inline-start still correct via logical props; contact markers flip side.
A11y: footer landmark; social links labelled; forms => docs/components/forms.md + file-uploader.md. CMS: contacts/blurbs/social URLs editable; copyright year generated. Assets: logo-full.png, footer.png (decorative).

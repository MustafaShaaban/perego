# Component — Preloader

Home only, first visit per session. DOM: .preloader#preloader[aria-hidden] > .preloader__stage(3 rings + glow + logo) + .preloader__bar>span + .preloader__word.
State mechanism: `.is-hidden` (opacity/visibility) hides it. z {z.preloader}=4000 (above everything incl lightbox).
Logic: sessionStorage['perego-preloaded']; reduced-motion OR already-seen => hide immediately; else hide ~900ms after paint, +200ms after load, hard safety net 2500ms.
Measurements: fixed inset0; radial bg #1a0338->#060010; stage 240×240; logo 168 wide (plLogo pulse 2.4s); rings 150/200/240 spinning (plRing); glow blur8 pulse; bar 200×3 with sweeping span; word 13px letter-spacing .34em uppercase muted, "بيريجو · PEREGO".
Reduced-motion: skip entirely (hide at once). A11y: aria-hidden; must never trap the page (safety net). Acceptance: shows once/session; never blocks content; disabled under reduced-motion.

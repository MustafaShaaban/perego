# Component — SiteHeader

Purpose: brand + primary nav + language + CTA. Persistent on every page.
DOM: header.site-header#siteHeader > .container.site-header__inner [ .logo | nav.main-nav#mainNav |
a.header-cta | .lang-toggle | button.nav-toggle#navToggle ]; sibling .nav-backdrop#navBackdrop.
State mechanism: `.is-scrolled` on the header (added when window.scrollY > 20).

Measurements (desktop @1440):
- position: sticky; top:0; z-index: {z.header}=1000.
- inner: display flex; align-items center; gap clamp(20px,3vw,48px); padding-block 22px => height ~90px.
- logo img: height 46px, width auto. CTA .header-cta: padding 10px 22px; hidden <=1024px.
- Default variant "overlay": transparent bg; first section overlaps up by 90px (header-hero-overlap).
- Scrolled: background rgba(16,0,43,0.82); backdrop-filter blur(14px); box-shadow 0 1px 0 rgba(216,106,243,0.15).
- Nav links: font-weight 700; 16px; 2px accent underline via ::after scaleX (0->1) on hover/.is-active.

Variants: overlay (hero pages) · solid-context (editorial; same sticky, .is-scrolled after 20px).
Active item: page sets .is-active on its nav link; service pages set it on the Services parent.

Interaction states:
| Element | State | Visual |
|---|---|---|
| header | scrollY<=20 | transparent (overlay) |
| header | scrollY>20 | .is-scrolled: translucent + blur + hairline |
| nav link | hover/active | accent underline scaleX(1) |
| nav link | focus-visible | 2px accent outline, offset 3px |

Responsive: <=1024px hamburger appears, CTA hides, nav becomes slide-in panel (see mobile-navigation).
<=1080px nav gap tightens to 16px.
RTL: entire bar mirrors (logical props); logo left in LTR / right in RTL; lang-toggle margin-inline-start:auto.
A11y: nav aria-label "Primary"; skip-link target #main; logo aria-label "Perego — home".
CMS: menu items/labels/order editable; logo asset locked (logo-full.png). Empty: nav must always render Home + Contact.
Assets: logo-full.png (46px). Acceptance: sticky + scrolled state; active item correct per route; keyboard nav; RTL mirror.

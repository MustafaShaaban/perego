# Component — HomeHero (slider)

Purpose: full-viewport intro slider, 3 text slides over a prism background. Home only.
DOM: section.hero#hero > .hero__prism(img hero-bg.png) + .container.hero__inner>.hero__content[.hero-enter]
[ 3× .hero__slide(data-slide) with title+text | .hero__cta a.btn--accent ] + .hero__dots[role=tablist] 3× button.hero__dot[role=tab].
State mechanism: active slide = not [hidden]; others [hidden]. Active dot = `.is-active` + aria-selected. Entrance = `.hero-enter` (heroIn 0.8s).

Measurements: min-height 100vh; margin-top -94px; padding-top 94px (reconcile to 90px header, C-09);
bg radial-gradient(#2a0850->#060010). prism img object-fit cover, animation heroDrift 26s (reduced-motion: off).
Title fs-hero clamp(42,5.2vw,76)/700/lh1.02. text max 1150px, margin-top 28, fs-lead. CTA margin-top 44.
Dots bottom 40px; dot 26×8 pill rgba .35; active 40×8 accent + glow.
Slide 1 uses real <h1> ("What We Believe"); slides 2 & 3 use p.hero__title (only ONE h1 per page).
Rotation: 6500ms interval; pause on mouseenter + tab hidden; reduced-motion => no auto-rotate.

| Current | Event | Next | Visual | Functional |
|---|---|---|---|---|
| slide n | 6.5s timer | slide n+1 (wrap) | old [hidden], new .hero-enter; dots update | index advances |
| any | dot click | that slide | switch + restart timer | aria-selected moves |
| running | mouseenter hero / tab hidden | paused | frozen | timer cleared |
| paused | mouseleave / tab visible | running | resumes | timer restart |
| any | reduced-motion | static | slide 1 only, no drift/pulse | no timer |

Responsive: <=680px min-height 92vh. Text scales via clamp. RTL: mirrors; content reads Cairo; dots centered (unaffected).
A11y: dots role=tab/aria-selected in a tablist; hero aria-label "Introduction"; prism aria-hidden. CMS: slide titles+text + CTA editable (hero slides source). Asset: hero-bg.png (LCP, preload, no-lazy).

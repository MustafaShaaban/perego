# Component — SelectedWorkGallery (work-masonry) + WebsiteShowcase

## SelectedWorkGallery (masonry) — services overview + video/motion/graphic service pages + project gallery
DOM: .work-masonry ( m1..m15 buttons + .work-brand card ) then .work-more-grid#workMore[hidden] (8) then Load more button#loadMore.
State mechanism: work-more hidden via [hidden] attr; Load more sets grid.hidden=false, hides button, reveals cards.
Grid: 7 columns (1fr 1fr 1fr 0.5fr 1fr 1fr 1fr), auto-rows clamp(110,11vw,158), gap clamp(10,1.1vw,16). Named placements m1..m15 (see styles.css). brand card = col 4/5 row1/3, bg brand-card-bg.png + rotated logo (non-interactive, aria-hidden, cursor default).
work-card: radius 16; img object-fit cover, scale1.07 on hover; overlay darken on hover. play-btn (54, accent, triangle) OR work-zoom (+ magnifier) OR work-badge "Gallery".
Triggers: data-video => lightbox video; data-image => image; data-gallery(csv) => gallery. All open the ONE global lightbox.
Responsive: <=760 auto-rows 120, more-grid 2col. <=520 masonry 2col, all cards auto-flow (m1/m11 span 2col×2row), brand card hidden.
work-more-grid: 3 cols -> 2 (<=760) -> 1 (<=520); cards aspect 16/10.

| Current | Event | Next | Visual | Functional |
|---|---|---|---|---|
| collapsed | Load more click | expanded | work-more shows, button hidden, cards reveal | 8 more tiles appended visually |
| tile | click | — | lightbox opens | mode per data-attr |

## WebsiteShowcase — Website Making page ONLY
DOM: section.web-showcase > head (h2 "Websites we've built" + p) + .web-filters (pills) + .web-grid#webGrid ( .web-card[data-category] ).
web-card: browser chrome bar (3 traffic-light dots + url pill) + .web-card__shot (aspect 16/10, img pans on hover) + body (title + cat + Visit link).
State mechanism: filter `.is-active` on pill; cards toggle `.is-hidden`/`.is-filtering`. Grid 2col -> 1col at 720px.
Card SHOT click => global lightbox (image). Visit link => external navigate. Filters: All / E-Commerce / Corporate / ...
Assets: portfolio-*.png (PLACEHOLDER). Acceptance: masonry placements exact; brand card non-interactive; Load more; lightbox modes; filter reflow.

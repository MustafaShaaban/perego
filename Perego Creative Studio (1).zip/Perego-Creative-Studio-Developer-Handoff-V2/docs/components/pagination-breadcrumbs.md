# Component — Pagination, Breadcrumbs, LegalTOC

## Pagination (.pagination)
DOM: nav.pagination[aria-label=Pagination] > Prev + numbered a/span + Next. Item min 44×44, radius 10, border rgba(216,106,243,.28).
States: .is-current (accent bg, #12012e), .is-disabled (opacity .35, pointer-events none), hover (border accent + tint).
RTL: order mirrors; Prev/Next swap sides via logical flow. A11y: aria-label; current = aria-current=page; disabled not focusable.

## Breadcrumbs (.page-crumb)
DOM: nav.page-crumb[aria-label=Breadcrumb] > a ... <span>/</span> ... current(text). 13px muted; links muted->accent-soft; separators opacity .5.
RTL: reading order mirrors; separators unchanged.

## LegalTOC (.legal-toc)
Sticky (top 110px) numbered anchor list; scroll-spy `.is-active` on current section link; collapses to static at <=900px. Body headings scroll-margin-top 110px, .num accent prefix. A11y: nav landmark; active reflects scroll position.

# Interactions & Behaviour

All behaviour lives in `site/js/main.js` (vanilla, one IIFE per feature). `main.js` adds `class="js"` to `<html>` on init — this is the progressive-enhancement flag CSS uses to hide reveal content only when JS is present.

## Header & navigation
- **Sticky header:** toggles `.is-scrolled` past 20px scroll (adds blur + bg + hairline border).
- **Mobile nav (≤1024px):** hamburger toggles a right-side slide-in panel + backdrop; body scroll-lock stores/restores scroll position; Esc + backdrop click + link click close it; the Services parent toggles its submenu instead of navigating. RTL mirrors the slide direction. *(Build: add focus trap + focus restore — see ACCESSIBILITY_HANDOFF.)*
- **Services dropdown:** hover / `:focus-within` on desktop, tap-accordion ≤1024px (`aria-expanded`).

## Language toggle (AR/EN + RTL)
- Swaps `documentElement` `lang` + `dir` (ltr↔rtl); toggles `body.lang-ar`; persists to `localStorage["perego-lang"]`; re-applies on load. Layout mirrors automatically via CSS logical properties. *(Build: swap the string bundle from `content/{lang}.json` and switch the font stack to Cairo for Arabic.)*

## Hero slider
- Auto-advancing headline slider (6.5s) with dot tabs; pauses on hover + when tab hidden; off under reduced-motion. *(Build: add prev/next + pause/play + `aria-live` + stop-on-interaction — see ACCESSIBILITY_HANDOFF.)*

## Scroll reveal
- `.reveal` elements fade/translate in via IntersectionObserver (`.is-visible`), `data-delay="1|2|3"` staggers. Hidden state is gated behind `.js`; disabled under reduced-motion. If IntersectionObserver is missing, everything is shown immediately.

## Clients sliders
- **Corporate:** horizontally scrollable track of equalizer tiles (real `<button>`s), arrow paging, drag-to-scroll, edge-disabled arrows. Each tile opens the lightbox gallery. **Build note:** the tiles are generated in JS from a `pool` array — render them server-side in production so they exist without JS, and swap `pool` for real client media (image paths, `.mp4/.webm`, or YouTube `/embed/` URLs).
- **Individual:** scrollable track with arrow paging; cards link to external channels and open the lightbox video.

## Lightbox (mixed media)
- Detects type by URL: `/embed/` or youtube/vimeo → iframe; `.mp4/.webm/.ogv/.mov` → `<video controls autoplay>`; else `<img>`. Galleries via `data-gallery="url,url,…"`; prev/next + clickable dots + keyboard (Esc, ←/→); body scroll-lock. *(Build: dialog semantics + focus trap + counter — see ACCESSIBILITY_HANDOFF.)*

## Portfolio archive filter
- `.portfolio-filter` chips filter `#portfolioGrid [data-category]` cards by adding/removing `.is-hidden`; `#portfolioEmpty` message shows when a category has **no results**; active chip is `.is-active` + `aria-pressed`. *(Build: consider real URL params `?service=` + server-side filtering for SEO/pagination.)*

## Website-making showcase filter
- `.web-filter` chips filter `#webGrid .web-card[data-category]` with `.is-hidden` / `.is-filtering` (fade).

## Service chooser (contact page)
- Four `<button aria-pressed>` toggles; **click/tap toggles any number** (Shift no longer required); writes the selection into the hidden `services` field; `?service=` query param pre-selects.

## Forms — states & validation
Client-side only in the prototype; wire submit to CoreX. Every form must represent these states (copy in `content/*.json` → `forms`):
- **default · hover · focus · filled** (visual)
- **required** (marked) · **invalid** (per-field `.field-error`, `aria-live`) · **form-level error** (summary, `role="alert"`)
- **upload in progress** (careers CV) · **submitting** (button `.is-loading` spinner, disabled)
- **success** (`role="status"`, per-form message) · **server error** · **spam/rate-limit** · **file-type error** · **file-size error**
- Do **not** simulate success as the only outcome — map real responses. Required vs optional and validation rules are in `CONTENT_MODEL.md`.

## File upload (careers)
- `.file-drop` label shows the chosen filename + `.has-file`; accepts `.pdf,.doc,.docx`. *(Build: enforce type + 10 MB size limit → `forms.fileWrongType` / `forms.fileTooLarge`.)*

## Legal TOC scrollspy
- Sticky `.legal-toc`; highlights the active section link as you scroll (sections have `scroll-margin-top`). Collapses to one column ≤900px.

## Preloader (home only)
- Shows on `index.html` **first visit per session** (`sessionStorage["perego-preloaded"]`); **skipped under reduced-motion**; hides ~0.9s after first paint (does not wait for all resources); hard safety timeout hides it by 2.5s so a JS/asset failure can never block the page. Removed from all other pages.

## Footer year
- `#year` set to the current year.

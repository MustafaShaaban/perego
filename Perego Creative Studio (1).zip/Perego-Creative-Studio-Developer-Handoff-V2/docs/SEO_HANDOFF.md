# SEO Handoff

Applies to the CoreX production build. The prototype `<head>`s carry accurate titles/descriptions per page; below is the full model plus what to add in production.

## Global head requirements (every indexable page)

- `<html lang="en" dir="ltr">` / `<html lang="ar" dir="rtl">` — set per language.
- Unique `<title>` and `<meta name="description">` (see per-page table).
- Canonical: `<link rel="canonical" href="{{absolute_url}}">`.
- Language alternates on **every** page:
  ```html
  <link rel="alternate" hreflang="en" href="https://perego.example/{path}" />
  <link rel="alternate" hreflang="ar" href="https://perego.example/ar/{path}" />
  <link rel="alternate" hreflang="x-default" href="https://perego.example/{path}" />
  ```
- Open Graph: `og:title`, `og:description`, `og:type` (website/article), `og:url`, `og:image` (1200×630, see below), `og:locale` (`en_US` / `ar`).
- Twitter/X: `twitter:card=summary_large_image`, `twitter:title`, `twitter:description`, `twitter:image`.
- `og:image` guidance: 1200×630 PNG/JPG on the dark-violet background with the Perego mark + a representative visual; provide EN and AR variants. Default share image = prism hero art + logo.

## Per-page metadata

| Page | Title | Meta description | Index? | OG type |
|---|---|---|---|---|
| Home | Perego — Creative Studio | Creative studio for the Arab region: video editing, 2D motion graphics, graphic design, website making. | index,follow | website |
| Services overview | Our Services — Video, Motion, Design & Web \| Perego | Perego offers video editing, 2D motion graphics, graphic design and website making — one team, one standard for craft. | index,follow | website |
| Video Editing | Video Editing & Post-Production — Perego | We turn raw footage into polished, high-impact videos that tell your story and engage your audience. | index,follow | website |
| 2D Motion Graphics | 2D Motion Graphics & Animation — Perego | Engaging 2D motion graphics that simplify ideas, strengthen brand identity, and bring stories to life. | index,follow | website |
| Graphic Design | Graphic Design & Brand Identity — Perego | Visuals that communicate clearly, build brand presence, and connect with your audience. | index,follow | website |
| Website Making | Website Making & Development — Perego | Fast, responsive websites that showcase your brand and turn visitors into customers. | index,follow | website |
| Portfolio | Our Work — Portfolio \| Perego | Selected work across video, motion, design and web for clients across the Arab region. | index,follow | website |
| Project | {Project} (Case Study) \| Perego | {One-line project summary}. | index,follow | article |
| Contact | Start a Project — Perego | Tell us about your project. Choose your services and send a brief to the Perego studio. | index,follow | website |
| Journal | The Perego Journal — Perego | Notes on video, motion, design and the web from the studio floor. | index,follow | website |
| Article | {Title} — Perego Journal | {Excerpt}. | index,follow | article |
| Search | Search results — Perego | — | **noindex**,follow | website |
| Page | {Title} — Perego | {Lead}. | index,follow | website |
| Terms | Terms & Conditions — Perego | The terms governing use of the Perego website and services. | index,follow | website |
| Privacy | Privacy Policy — Perego | How Perego collects, uses and protects your personal data. | index,follow | website |
| 404 | Page not found — Perego | — | **noindex**,follow | website |

> The Services overview description was corrected — it previously described only Video Editing.

## Structured data (JSON-LD)

- **Organization** (site-wide, in the head or footer): name "Perego", alternateName "بيريجو", url, logo, sameAs [social URLs], contactPoint (email/phone). No address/geo — the studio has no public physical location; **do not fabricate one**.
- **WebSite**: name, url, inLanguage ["en","ar"]. Add `SearchAction` **only if** production search resolves a real query URL (`/?s={search_term_string}`).
- **WebPage**: per page, with `inLanguage` + `isPartOf` WebSite.
- **BreadcrumbList**: mirror the visible `.page-crumb` on Services detail, Portfolio, Project, Journal, Article, Legal, Search.
- **Service**: on each service detail page — `name`, `provider` (Organization), `serviceType`, `areaServed` "Arab region".
- **Article**: on journal single — headline, author (Person), datePublished, image, publisher.
- **CreativeWork** (or `VisualArtwork`): on project pages — name, creator (Organization), about/keywords, image. **No `aggregateRating`/`review`** unless real, verifiable reviews exist.

Never populate structured data with invented reviews, ratings, prices, addresses, or achievements.

## H1 / internal-linking / alt-text

- One H1 per page — see `ROUTES_AND_TEMPLATES.md` for the exact H1 of each template.
- Internal links: every service page links to Contact (`?service=`); portfolio links to projects; projects link to related projects + Contact; footer links to Journal + legal on every page; breadcrumbs everywhere below Home.
- Image alt text: descriptive alt on all content images (portfolio thumbnails name the project + service); **empty `alt=""`** on decorative backgrounds/prism/wavy art and icon glyphs; see `ASSET_MANIFEST.md`.
- Add explicit `width`/`height` on content `<img>` (done on portfolio/project); mark the hero/LCP image `fetchpriority="high"` and everything below the fold `loading="lazy"`.

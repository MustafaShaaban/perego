# Content Model

Fields Claude Code should build in CoreX. Strings themselves live in `content/en.json` + `content/ar.json` (identical key trees). Real vs placeholder content is flagged.

## Hero slides (Home) — repeatable (3)
`title` (text), `body` (rich text), plus one shared `cta_label` + `cta_url`. **Real copy.** Keep exactly one as the page H1.

## Services — 4 fixed entries
`name` (short), `full_name`, `slug`, `card_image`, `hero_bg`, `intro_p1`, `intro_p2`, `ui_image`, and a **process** repeater of 4 `{label, desc}` steps, plus `meta_title`/`meta_description`. **Real copy** (process for Website Making is a reasonable draft — confirm with Perego). Do not rename "Website Making" in visible content.

## Projects (Portfolio) — repeatable — **PLACEHOLDER DATA**
`title`, `slug`, `category` (enum: video|motion|design|web), `client` (optional — only with permission), `year`, `role`, `deliverables` (list), `hero_media` (image/video/embed), `gallery` (media list), `overview`, `challenge`, `approach`, `solution`, `result`, `related` (refs). Prototype shows 9 example cards + 1 case study clearly marked "example"/"Sample Client". **Replace with real projects. Do not invent results/metrics.**

## Clients — repeatable — **PLACEHOLDER MEDIA**
- Corporate: `name`, `logo`/`icon`, `gallery` (mixed media for the lightbox). Prototype uses an equalizer glyph + a `pool` media array in `main.js`.
- Individual: `title`, `subtitle`, `stat` (e.g. "+1M views"), `thumbnail`, `channel_url`, `video_url`. **Do not fabricate view counts or names** — replace with real, approved data.

## Journal posts — repeatable — **PLACEHOLDER**
`title`, `slug`, `category`, `excerpt`, `featured_image`, `author` (name, avatar/initials, bio), `date`, `read_time`, `body` (rich text: h2/h3, blockquote, figure, ul/ol, code), `tags`, `related`. Comments: `name`, `email`, `body`, `date`, `parent` (for replies), `status` (pending/approved). **Replace placeholder posts/comments.**

## Search
`query`, `results` (title, url, excerpt, type), `count`. Prototype shows example results. `search.empty` + `emptyHint` states required.

## Contact / project brief
Fields: `name`* , `email`* , `phone`, `company`, `budget` (enum), `subject`* , `message`* , `services` (multi, from chooser). Validation: email format, required marks, budget from fixed list. **Real contact details** in footer.

## Careers ("Join us")
`name`* , `portfolio` (URL), `cv` (file: PDF/DOC/DOCX, ≤10 MB). File errors → `forms.fileWrongType` / `forms.fileTooLarge`.

## Legal (Terms, Privacy) — **DRAFT, needs legal review**
`title`, `last_updated`, `sections` (repeater: `{heading, body}` → drives the TOC). Mark drafts with `legal.reviewNote`.

## Global / settings
Brand (name EN/AR, logo), nav labels, footer blurb, social links (Instagram/Facebook/LinkedIn/YouTube/WhatsApp — **real handles needed**, currently platform placeholders), contact emails/phones (real), site language, per-page SEO fields.

## Required vs optional (forms)
| Field | Required | Notes |
|---|---|---|
| Contact: name, email, subject, message | ✔ | email format |
| Contact: phone, company, budget | ✘ | budget from enum |
| Careers: name | ✔ | |
| Careers: portfolio, cv | ✘ | cv type+size validated |
| Comment: name, email, comment | ✔ | email not published |

Placeholder markers used in the prototype: the words **"example"**, **"Sample Client"**, and the portfolio intro note "Example projects shown below — to be replaced with Perego's real work."


## Form validation & security (implemented in the prototype)

Client-side validation runs on blur + on submit; `aria-invalid` + a live `.field-error` are set per field. **These are UX/first-line checks — Claude Code must re-validate and sanitise everything server-side in CoreX** (never trust the client).

**Length limits** (hard `maxlength` on the input + JS check; a live `X / max` counter is shown on textareas):

| Field | Min | Max |
|---|---|---|
| name | 2 | 80 |
| email | — | 120 (must match email pattern) |
| phone | — | 24 (chars `+ ( ) - space digits`, 7–24 long) |
| company | — | 80 |
| subject | 3 | 120 |
| portfolio (URL) | — | 200 (must match URL pattern) |
| message / comment | 10 | 1200 (live character counter) |

Fields without an explicit `maxlength` get a sensible default cap applied by JS (defense-in-depth against oversized payloads).

**File upload (careers CV):** accepted types `.pdf .doc .docx`; max size **10 MB**. Wrong type → "Unsupported file type…"; too large → "This file is too large…".

**Server-side requirements for CoreX:** enforce the same limits + types server-side; add CSRF/nonce protection, rate-limiting (see `forms.rateLimited`), spam/honeypot or captcha, MIME sniffing on the uploaded file (not just extension), and output-escaping of all stored values before they appear in admin/emails. Reject, don't truncate, over-limit input.
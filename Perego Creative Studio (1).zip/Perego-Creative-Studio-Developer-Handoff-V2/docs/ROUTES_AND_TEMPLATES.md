# Routes & Templates

16 HTML page templates in `site/` (plus the email templates). Each row: file → purpose → primary H1 → suggested CoreX template → suggested URL slug (EN / AR).

| File | Purpose | H1 (one per page) | CoreX template | Slug EN / AR |
|---|---|---|---|---|
| `index.html` | Home — hero slider, services teaser, about, clients | **What We Believe** (slide 1 only; slides 2–3 are `<p>`) | `front-page` | `/` · `/ar/` |
| `services.html` | Services overview — all four services, shared process | **Our Services** | Services archive / custom page | `/services` · `/ar/الخدمات` |
| `service-video-editing.html` | Service detail | **Video Editing & Post-Production** | Service single | `/services/video-editing` |
| `service-motion-graphics.html` | Service detail | **2D Motion Graphics & Animation** | Service single | `/services/motion-graphics` |
| `service-graphic-design.html` | Service detail | **Graphic Design & Brand Identity** | Service single | `/services/graphic-design` |
| `service-website-making.html` | Service detail | **Website Making** | Service single | `/services/website-making` |
| `portfolio.html` | Portfolio archive — filter by service | **Our Work** | Project archive | `/work` · `/ar/الأعمال` |
| `project.html` | Single project / case study | **[Project title]** | Project single | `/work/{slug}` |
| `contact.html` | Contact / Start-a-Project hub | **Start a Project** (`.sr-only`) | Custom page template | `/contact` · `/ar/تواصل` |
| `archive.html` | Journal listing | **The Perego Journal** | `archive` (posts) | `/journal` · `/ar/المدونة` |
| `single-post.html` | Single journal article | **[Article title]** | `single` (post) | `/journal/{slug}` |
| `search.html` | Search results | **Search results** | `search` | `/?s=` |
| `page.html` | Default content page | **[Page title]** | `page` | `/{slug}` |
| `terms.html` | Terms & Conditions (legal) | **Terms & Conditions** | `page` (legal template) | `/terms` |
| `privacy.html` | Privacy Policy (legal) | **Privacy Policy** | `page` (legal template) | `/privacy` |
| `404.html` | Error page | **This page took a creative detour** | `404` | — |
| `emails/**` | Transactional emails | (email H1s) | Mailer templates | — |

## Global shell (every page)

- **Header** (`.site-header`, sticky): logo → primary nav → "Start a Project" CTA (hidden ≤1024px) → AR/EN toggle → hamburger (≤1024px). Gains `.is-scrolled` past 20px scroll.
- **Primary nav order:** Home · About Us · Services (dropdown → 4 service pages) · **Work** · Journal · Clients · Contact Us. Active item marked `.is-active` + `aria-current="page"`.
- **Footer** (`.site-footer`, `id="contact"`): standard 3-column (Contact us / quick-message form / Join-us careers form) + bottom bar (copyright + legal nav). Contact page uses the **flat** 2-column variant (`.site-footer--flat`).
- **Skip link** (`.skip-link` → `#main`) is the first focusable element on every page.

## Heading hierarchy (one H1 per page)

- **Home:** single `<h1>` = the active hero headline (slide 1). The other two slider headlines are `<p class="hero__title">` (visually identical) so there is exactly one H1. Section titles are `<h2>`; teaser/clients sub-blocks `<h2>`; cards `<h3>`.
- **Services overview:** `<h1>` "Our Services"; intro/process/selected-work/CTA are `<h2>`.
- **Service detail:** `<h1>` = the service's real name (with an "Our Services" eyebrow `<p>` above it, not a heading). "What we do" / "Our Process" are `<h2>`.
- **Portfolio archive:** `<h1>` "Our Work"; project cards `<h2>`.
- **Project:** `<h1>` = project title; Overview/Challenge/Approach/Solution/Result are `<h2>`.
- **Journal/Search:** page `<h1>`; cards `<h3>` (cards sit under the page title, below an implicit list).
- **Legal:** `<h1>` = document title; numbered sections `<h2>` (each with `scroll-margin-top` for the TOC).
- **Footer** headings are `<h2>` but come after `<main>`, so they never interrupt in-page document flow.

## Internal linking map

- Header CTA "Start a Project" → `contact.html`. Nav "Contact Us" → `#contact` (in-page footer quick form).
- Home service cards → the four `service-*.html` (Website Making card → `service-website-making.html`, **fixed**).
- Service tabs & `Start your project` → `contact.html?service=<Name>` (pre-selects the chooser).
- Portfolio cards → `project.html`; filters are client-side (`data-category`).
- 404 "Contact Us" → `contact.html` (no in-page footer on 404).

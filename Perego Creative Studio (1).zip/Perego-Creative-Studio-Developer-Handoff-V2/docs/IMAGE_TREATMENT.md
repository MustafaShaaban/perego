# IMAGE & ARTWORK TREATMENT (§13)

Per-asset treatment. Intrinsic sizes from docs/ASSET_MANIFEST.md (some marked "—" where the source is vector or unmeasured — measure before production). `object-fit`/`object-position` and crop are the REAL values from styles.css. Decorative = `alt=""` + `aria-hidden`; content = descriptive alt. Do not substitute visually-similar assets without Perego approval.

| File | Page/Section | Intrinsic | Display | fit / position | Crop (mobile) | RTL | Class | Lightbox |
|---|---|---|---|---|---|---|---|---|
| hero-bg.png | Home hero prism | 1920×1080 | full-bleed | cover / center; heroDrift scale 1.06–1.1 | art-direct taller crop for portrait | none | Decorative/**LCP** (preload, no-lazy, fetchpriority high) | no |
| about-hooded.png | Home about + Contact hero | 1600×900 | full-bleed bg | cover / 28% center (RTL 72% center) | vertical scrim <=900 | focal flips | Decorative | no |
| svc-hero-bg.png | Services + 4 service heroes | 1920×1108 | full-bleed | cover / center top; opacity .95 | full-bleed | none | Decorative (shared) | no |
| svc-banner-bg.png | (legacy svc-banner) | — | banner | cover, mix-blend screen, opacity .5 | banner | none | Decorative | no |
| services-hero.png | (alt services hero) | — | full-bleed | cover | full-bleed | none | Decorative | no |
| wavy-corners.png | teaser/clients/whatwedo bg | 1800×1013 | section bg | cover, opacity .5–.6 | scale/hide | none | Decorative | no |
| footer.png | Footer texture | — | footer bg | cover / center | cover | none | Decorative (standard footer only) | no |
| brand-card-bg.png | work-masonry brand tile | 361×1387 | portrait tile | cover | hidden <=520 | none | Decorative | no |
| brand-card-mark.png / brand-wordmark.png | brand tile | — | centered, rotated -90° | contain | hidden <=520 | rotation unchanged | Decorative | no |
| corp-icon.png | Corporate tiles | 178×179 | 44% of tile | contain | contain | none | **Placeholder** (real logos) | no (C-05) |
| card-video-editing/-motion-graphics/-graphic-design/-website-making.png | Home service cards | 560×680 | 4-up (5/6) → 1-up | cover | 16/10 <=440 | grid mirror | Content (alt=service) | no (navigate) |
| ui-video-editing.png | video whatwedo + overview whatwedo | 2341×1667 | half, rotate -1.2° | cover | full, no rotate | order flip | Content | no |
| ui-motion-graphics.png | motion whatwedo | 2341×1667 | half | cover | full | — | Content | no |
| ui-graphic-design.png | graphic whatwedo **+ website whatwedo (reused)** | 2341×1667 | half | cover | full | — | Content | no |
| (missing) ui-website | website whatwedo | — | — | — | — | — | **Gap**: no dedicated asset; graphic-design UI is reused. If a website-specific image is required, request it from Perego (CONFLICTS follow-up). | no |
| portfolio-1…9.png | works masonry / archive / project / clients pool | 640×400 | grid tiles | cover; hover scale 1.07 | reflow grid | none | **Placeholder** (real work) | YES (image/gallery; video items use embed URLs) |
| client-review-crop.png | Individual client thumb | — | 42% card col | cover | full | none | **Placeholder** | conditional (C-04) |
| icon-clapper/-film-l/-film-h/-star/-hands/-pen/-laptop/-browser.png | process steps | small | 56px (84 tablet) | contain, drop-shadow accent | 44px | none | Decorative (alt="") | no |
| service-video-editing/-motion-graphics/-graphic-design/-website-making.svg | source vectors | vector | — inline if used | — | — | — | Decorative (editable source) | no |
| logo-full.png | header/footer/preloader/email/brand tile/watermark | 552×170 | 46px header; 168 preloader | contain | ~40px | none | Content (alt "Perego بيريجو"); prefer SVG master | no |

## Production rules
- Ship WebP/AVIF + PNG/JPG fallback; explicit width/height; lazy-load below the fold; hero-bg preloaded (LCP).
- srcset/sizes (320/640/960/1280/1920) for card-*, ui-*, portfolio-*, hero.
- Compress ui-* hard (render ≤700px though intrinsic 2341). Prefer SVG for logo + icons.
- Lightbox needs a full-size asset per item + poster for videos; thumbnails separate from full media.
- Replace every **Placeholder** with rights-cleared media before launch; update lightbox media URLs (remove Rickroll embed).

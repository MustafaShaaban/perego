# QA Checklist

Verify before launch. ✔ = handled in this prototype; ☐ = to verify/complete in the CoreX build.

## Visual
- ✔ Dark-violet identity, magenta accent, glass panels, prism art preserved (no redesign).
- ✔ Consistent spacing/tokens across pages (single stylesheet + `design-tokens.json`).
- ☐ No unexplained white gaps, clipping, or overflow at any breakpoint (EN + AR).

## Content
- ✔ Real English marketing copy preserved; only corrections made (Services overview meta, service H1s).
- ✔ Complete Arabic (MSA) content for all UI + marketing strings (`content/ar.json`).
- ✔ No mixed-language interface (all strings keyed).
- ✔ No fabricated business claims (no awards/counts/ratings/metrics).
- ✔ Placeholder content clearly marked ("example", "Sample Client").
- ☐ Replace placeholder portfolio/journal/search/comment content + imagery with real data.
- ☐ Legal Terms/Privacy reviewed by counsel.

## Technical / prototype
- ✔ Home "Website Making" card links to `service-website-making.html` (was wrong).
- ✔ Malformed/duplicate `#eq` SVG symbol fixed.
- ✔ Dead `href="#"` links replaced (social → platform placeholders; pagination → `?page=`; corp tiles → `<button>`).
- ✔ One H1 per page; service pages use their real name; hero has a single H1.
- ✔ Shift-key multi-select removed → click/tap toggle.
- ✔ Progressive enhancement: reveal content visible without JS (`.js` gate).
- ✔ Preloader home-only, first-visit, reduced-motion-safe, never blocks the page.
- ✔ Skip-to-content link on every page.
- ✔ No console errors on the prototype pages.
- ☐ Confirm no duplicate IDs after CoreX loops render (watch repeated card/field IDs).
- ☐ All assets load; add `width`/`height`/`srcset` site-wide.

## Responsive
- ☐ Every page at 320/375/430/768/1024/1280/1440/wide, EN **and** AR.
- ☐ Mobile forms + service chooser usable; nav usable at all widths; no horizontal scroll except client carousels.

## Accessibility (see ACCESSIBILITY_HANDOFF for [DONE] vs [BUILD])
- ✔ Keyboard-operable nav, chooser, forms, filters, buttons; visible focus; skip link.
- ✔ Accent buttons dark-on-magenta (AA); errors not colour-only; reduced-motion respected.
- ☐ **[BUILD]** Hero slider prev/next + pause/play + live region + stop-on-interaction.
- ☐ **[BUILD]** Lightbox as a true dialog (role/aria-modal/focus-trap/restore/counter/inert).
- ☐ **[BUILD]** Mobile-nav focus trap + restore; `aria-invalid`/`aria-describedby` + form-level error summary.

## SEO
- ✔ Unique title + description per page; Services overview meta corrected; one H1 each.
- ☐ Add hreflang (en/ar/x-default), canonical, OG/Twitter, JSON-LD (Org/WebSite/WebPage/Breadcrumb/Service/Article/CreativeWork) — no fake reviews/ratings/addresses.
- ☐ `noindex` search + 404.

## Emails
- ✔ 6 templates × EN/AR; RTL correct; CTA contrast fixed; preheaders present; merge fields documented.
- ☐ Wire form→template mapping; add plain-text parts; replace `perego.example` + confirm real send language logic.

## Handoff
- ✔ No duplicate website folder in `site/`; source vs preview assets separated (`source/` vs `site/assets`).
- ✔ Tokens exported; component states documented; email + CoreX mapping included.

---

## Decisions Claude Code must NOT make without Perego's confirmation
1. **Real social handles** — links currently point to platform homepages (placeholders).
2. **Website Making process steps** — the 4 steps are a reasonable draft; confirm the studio's actual process.
3. **Any project results / metrics / client names** — must be real and client-approved; never invent.
4. **Legal copy** — Terms/Privacy must be lawyer-reviewed before publishing.
5. **Budget ranges** — the `$` ranges on the contact form are assumptions; confirm currency + tiers.
6. **Which email address/phone is primary** — two of each are listed; confirm routing + reply-to.
7. **Whether search + `SearchAction` is truly supported** — only add the schema if production search resolves real query URLs.
8. **Careers as a dedicated page** — currently the footer "Join us" form; promote to `careers.html` only if real listings exist.

## Content Perego still needs to supply
Real portfolio projects (media + copy, no invented results) · real journal articles · real client logos/media + individual-client stats · real social profile URLs · confirmed contact routing · final legal text · optional OG share images (EN/AR).

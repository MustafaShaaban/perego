# Responsive Behaviour

Design width 1440px (`--maxw`). Fluid type via `clamp()`; spacing via `--gutter` / `--section-y`. Verify every page **in both EN (LTR) and AR (RTL)** at: 320, 375, 430, 768, 1024, 1280, 1440, and wide.

## Breakpoints (from `styles.css`)
| Width | Effect |
|---|---|
| 1080px | Nav gap tightens (watch longer Arabic labels) |
| **1024px** | Mobile nav (hamburger) engages; header "Start a Project" CTA hidden |
| 960 / 620px | Client slider items-per-view step down |
| 900px | Home about → 1 col; footer → 1 col; legal → 1 col; blog → 2 col |
| 720px | Website-making showcase → 1 col |
| 640px | Blog grid → 1 col |
| 560px | `.field-row` → 1 col |
| 520px | Works masonry / service tabs reflow |
| 480px | Search button padding tightens |

## Per-area notes
- **Header:** ≤1024 hamburger; logo scales; language pills stay visible. Arabic nav labels are wider — if they crowd at ~1080, allow the nav to wrap or reduce gap earlier in the AR build.
- **Hero:** min-height 100vh; headline `clamp(42–76px)`. Re-check 320–430px that the longest headline (EN "Built To Be Seen" / AR equivalents) doesn't overflow; dots stay tappable (≥44px hit area).
- **Service cards / tabs:** 4→2→1; tab tiles reflow ≤520.
- **Portfolio masonry / blog grid:** 3→2→1; cards keep 16/10 media; filter chips wrap centered.
- **Lightbox:** controls stay ≥44px and inside the viewport on small screens; media fits with letterboxing.
- **Client cards:** horizontal scroll is the **only** intentional horizontal overflow — arrows + drag; everything else must not scroll horizontally.
- **Forms:** field rows stack ≤560; file-drop full width; budget select full width; submit full-width on narrow.
- **Legal:** TOC sticky sidebar → stacked top ≤900; article measure caps ~760px.
- **Footer:** 3 cols → 1 col ≤900; long emails/phones wrap (`overflow-wrap`), never overflow.
- **Email templates:** 600px table → fluid `max-width:100%`; summary tables stack readably on mobile clients; test long `{{message}}`.
- **Landscape mobile:** hero uses min-height not fixed height, so short landscape viewports scroll rather than clip.

## Hard rules
- **No horizontal page scroll** at any width in either language except the client carousels.
- Tap targets ≥44px (nav, dots, chips, arrows, buttons).
- Minimum body text 16px; never below 13px for labels.
- Re-test RTL at every breakpoint — mirroring can expose different wrap points than LTR.

# CoreX Design Mapping

Guidance for rebuilding the prototype in the **CoreX WordPress framework**. The static HTML is a **visual + behavioural reference only** — do not paste it into WordPress. This document does not prescribe CoreX/PHP code; it maps the design to the structures Claude Code should create.

## Suggested templates
| Design page | CoreX template |
|---|---|
| Home | Front page template |
| Services overview | Services archive (or a custom "Services" page template) |
| Service detail (×4) | Service single (custom post type `service`) |
| Portfolio archive | Project archive (`project` CPT) with service taxonomy filter |
| Project | Project single |
| Contact / Start a Project | Custom page template |
| Journal archive | Post archive |
| Single article | Post single |
| Search | Search results template |
| Default page | Page template |
| Terms / Privacy | Page template ("legal" variant with TOC) |
| 404 | 404 template |
| Emails | Mailer/notification templates (see EMAIL_HANDOFF) |

## Suggested dynamic content (CPTs / fields / taxonomies)
- **Hero slides** — repeater on the home template (or a `slide` CPT): title, body, CTA.
- **Services** — `service` CPT: name, full name, intro, process (4 steps), images, SEO. 4 fixed entries.
- **Projects** — `project` CPT: title, category (taxonomy: video/motion/design/web), client, year, role, deliverables, hero media, gallery, overview/challenge/approach/solution/result, related.
- **Project media** — repeater/gallery field (image / self-hosted video / embed URL) powering the lightbox.
- **Clients** — `client` CPT with a **client type** taxonomy (corporate / individual): name, logo, media gallery, stat, channel URL.
- **Journal posts** — native posts + categories + comments.
- **Contact details / social links** — site options (real emails/phones; real social handles needed).
- **Forms** — a forms plugin or custom handlers (contact, project brief, careers, comment) → mailer.
- **Site language** — bilingual setup (e.g. a multilingual plugin) driving `content/en.json` ↔ `ar.json`; `lang`/`dir` + font swap per language.
- **SEO metadata** — per-template title/description/OG/canonical/hreflang + JSON-LD (see SEO_HANDOFF).

## Suggested bespoke Perego components
These carry custom design/behaviour — build them as dedicated blocks/components, not generic patterns:
- Hero slider (headline rotator + dots + **prev/next/pause to add**).
- Services selector tabs (2×2 glass tiles, active state).
- Portfolio masonry + service filter (+ no-results state).
- Project gallery / accessible lightbox (dialog + focus trap + counter).
- Client carousel + corporate equalizer tiles + individual cards.
- Project-brief service chooser (multi-toggle, `?service=` preselect).
- Legal table-of-contents scrollspy.
- Branded preloader (home, first-visit, reduced-motion-safe).

## Reusable / standard patterns
Use established CoreX/WordPress patterns (don't over-engineer) for: header/footer partials, primary nav + mobile menu, breadcrumbs, pagination, post cards, comment list + form, search form, the page/legal prose styles, and standard form fields. Apply the Perego tokens (`design-tokens.json`) so these standard parts inherit the identity.

## Global shell
Turn the repeated header/footer into partials; the language toggle, skip link, and footer forms are global. Keep all layout on **CSS logical properties** so RTL mirrors for free.

# Email Handoff

Six transactional templates, each in **`emails/en/`** (LTR) and **`emails/ar/`** (RTL, MSA). All are 600px centered, table-based, inline-styled, email-client safe, and share the Perego branded shell (gradient header with the **Perego logo image**, dark card, violet summary box, signature footer). No web fonts are required — Arabic templates request Cairo but **fall back to Arial/Helvetica**, which every client renders. Accent CTA buttons use **dark text (`#2a0148`) on `#d86af3`** for AA contrast.

## Branding, signature & contact
- **Header logo:** each template shows `emails/assets/logo-full.png` (referenced as `../assets/logo-full.png` for local preview). **On send, swap this for an absolute hosted URL** (e.g. `https://perego.com/wp-content/.../logo-full.png`) — email clients can't load relative paths. Provide a `width`/`height` and keep `alt="Perego"`.
- **Signature (footer, every email):** "Best regards, **The Perego Team**" (AR: "مع أطيب التحيات، **فريق Perego**") followed by the single public address **`contact@perego.com`**.
- **No personal emails or phone numbers** appear anywhere — the previous per-person addresses/phones were removed. `contact@perego.com` is the one professional address (create this mailbox; change it in all 12 templates if a different address is chosen).
- Arabic emails still use the brand name **بيريجو** in Arabic-language copy (titles/body) — that is correct native usage; the removed item was the Latin "Perego بيريجو" text pairing, not the logo (the logo image legitimately contains both).

## Templates

| Template | Purpose | Trigger | Recipient | Subject pattern |
|---|---|---|---|---|
| `_default-template.html` | Base/master shell — duplicate to build any new email | — | — | `{{subject}} — Perego` |
| `contact-confirmation.html` | Confirms footer quick-message / contact-page message | Footer or contact message form submit | Submitter | `Thanks for reaching out — Perego` |
| `project-brief-confirmation.html` | Confirms the Start-a-Project brief | Contact page brief submit | Submitter | `We got your project brief — Perego` |
| `join-confirmation.html` | Confirms careers application | Footer "Join us" submit | Applicant | `We received your application — Perego` |
| `admin-notification.html` | Internal alert on ANY form submit (reusable) | Any form submit | Studio inbox | `New {{form_name}} submission — Perego` |
| `comment-notification.html` | Moderator alert for a new comment | Comment form submit | Moderator | `New comment awaiting review — Perego` |

## Merge fields

- **default:** `{{subject}} {{heading}} {{body_html}} {{cta_label}} {{cta_url}}` (footer signature + `contact@perego.com` are fixed, not per-send)
- **contact-confirmation:** `{{name}}` (req) · `{{email}}` (req) · `{{message}}` (req)
- **project-brief-confirmation:** `{{name}}` `{{email}}` (req) · `{{services}}` `{{budget}}` `{{subject}}` `{{message}}` · optional: `{{phone}} {{company}}` (hide the row/segment if empty)
- **join-confirmation:** `{{name}}` (req) · `{{portfolio}}` `{{cv_filename}}` (optional — show "—" if absent)
- **admin-notification:** `{{form_name}}` `{{submitted_at}}` `{{fields_html}}` (pre-rendered `<tr>` rows) `{{reply_email}}` (req)
- **comment-notification:** `{{commenter_name}} {{commenter_email}} {{comment_body}} {{post_title}} {{post_url}} {{approve_url}} {{submitted_at}}` (all req)

## Preheader text

Every user-facing template has a hidden preheader (`display:none;max-height:0`) summarising the email — added to contact- and join-confirmation in this pass. Keep preheaders ≤ ~90 chars.

## Fallbacks & long-content handling

- **CTA fallback URLs:** replace `https://perego.example` with the production domain. Always provide a plain-text URL fallback in the plain-text part.
- **Optional fields:** if `{{phone}}`, `{{company}}`, `{{portfolio}}`, or `{{cv_filename}}` are empty, hide the containing line rather than printing an empty label.
- **Long content:** `{{message}}` / `{{comment_body}}` wrap freely inside the summary box; the box has no fixed height. Test a 1,000-character message and a single-word one.
- **Plain-text equivalent:** every send must include a text/plain alternative — heading line, body, the summary fields as `Label: value`, and the CTA as a raw URL. Never send HTML-only.

## Form → email mapping

| Form | User email | Internal email |
|---|---|---|
| Footer quick message | `contact-confirmation` | `admin-notification` (form_name "Quick message") |
| Contact project brief | `project-brief-confirmation` | `admin-notification` (form_name "Project brief") |
| Careers "Join us" | `join-confirmation` | `admin-notification` (form_name "Careers application") |
| Journal comment | — | `comment-notification` |

## Language selection

Send the template matching the visitor's current site language (`perego-lang` in `localStorage`, or the submitting page's `lang`). Persist the chosen language with the lead so follow-ups match. Internal notifications may stay EN, but an AR copy exists for teams who prefer it.

Wire all sends to the CoreX mailer / a forms plugin. Do not add unrelated email workflows unless explicitly requested.

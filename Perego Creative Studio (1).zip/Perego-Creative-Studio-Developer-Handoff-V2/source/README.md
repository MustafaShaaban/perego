# source/ — editable originals (do NOT serve directly)

High-resolution / editable source artwork. These are **not** production assets — do not reference them from live markup. Export optimized, correctly-sized WebP/AVIF into `site/assets/images/` (see `docs/ASSET_MANIFEST.md`).

- `PEREGO_DESIGN_SYSTEM.md` — the original extracted design system (colours, type, layout, page/content notes).
- `vectors/` — editable SVG source for the four service illustrations, two home sections, and the contact artwork.

Additional large Illustrator artboards and raw PNG exports remain in the original delivery package (`uploads/` / `design_handoff_perego_website/`) and were intentionally **not** duplicated here to keep the implementation-ready folder lean.

# Perego (بيريجو) — Design System

Extracted from the Illustrator SVGs and the finished PNG mockups. Attach this to Claude Design alongside the prompt.

## Brand
**Perego / بيريجو** — creative studio for the Arab region. Services: Video Editing, 2D Motion Graphics, Graphic Design, Website Making. Dark, cinematic, neon-purple aesthetic. Bilingual EN + AR (RTL).

## Colors
| Token | Hex | Use |
|---|---|---|
| `--bg-deep` | `#10002b` | Primary background (darkest) |
| `--violet` | `#6c1eae` | Brand violet / gradient top |
| `--accent` | `#d86af3` | Magenta accent — buttons, active nav underline, EN toggle, play buttons, highlights |
| `--text` | `#ffffff` | Text |
| `--panel` | `#480383` | Card / panel fill |
| `--panel-overlay` | `#160435` | Overlay panels (used ~30% opacity) |

**Main background gradient:** `#10002b → #12012e → #1a0339 → #26074a → #370d63 → #4e1483 → #691da9 → #6c1eae`

**Hero glow gradient (screen blend):** `#c77dff → #7b2cbf → #3c096c → #280648 → #170329 → #0a0212 → #030005 → #000`

**Neon accent line grid (cyan→magenta):** `#31ffff → … → #7b8bf0 → … → #bd24e2` (thin 0.1–2.6px strokes; the perspective grid + wavy line patterns).

## Typography
**Open Sans** (Google Fonts) — Light 300 / Regular 400 / Semibold 600 / Bold 700.
**Arabic:** original design used GE SS Text Bold (licensed) → substitute **Cairo** or **Tajawal**.

Scale (desktop @1440px): Hero display ~58–74px Bold · Page H1 ~42–50px Bold · Section title ~34–36px Bold · Sub-heading ~22–28px Bold · Lead ~18–25px Regular · Body ~15–16px · Nav ~16px Bold · Small/labels ~13–14px.

## Layout / components
- Design width 1440px. Card radius ~29px; buttons & toggle pills ~9px.
- Translucent "glass" panels with thin `#d86af3` borders and inner glow.
- Sticky transparent header; magenta underline on active nav item.
- EN/AR toggle: two pill chips, active = filled magenta, inactive = dark.
- Buttons: magenta fill (SAY HELLO!, Send, Apply now) or dark (START YOUR PROJECT on some pages).

## Navigation (global)
Logo (Perego + بيريجو) · Home · About Us · Clients · Video editing · Motion graphics · Design · Contact Us · AR/EN toggle.

## Pages & content
- **Home:** Hero slider "What We Believe" + SAY HELLO! (3 dots) → "Services we can help you with" + See All Services + 4 cards (Video Editing, 2D Motion Graphics, Graphic Design, Website Making) → Our mission → Clients teaser.
- **About Us:** hooded-figure hero + two panels — About Us copy + Our mission copy (see prompt for full text).
- **Clients:** Corporate Clients (grid of equalizer-icon logo slots) + Individual Clients (REVIEW EL ETNEN / intertainment show / +1M views cards).
- **Services landing:** "Our Services" hero with 4 tabs → What we do → Our Process (4 steps) → portfolio grid → footer.
- **Service pages (3):** banner hero + START YOUR PROJECT → What we do → Our Process → portfolio grid → footer.
  - Video Editing & Post-Production: Footage Review → Creative Editing → Effects & Refinement → Delivery & Revisions.
  - 2D Motion Graphics & Animation: Understanding the Idea → Concept & Storyboard → Animation & Design → Review & Delivery.
  - Graphic Design & Brand Identity: Brand Understanding → Visual Direction → Design Execution → Review & Delivery.
- **Contact Us:** "Choose your service" (3 multi-select cards, Shift-key hint) + form (Full name, E-mail, Message Subject, Your message, Send) with Arabic RTL mirror.

## Footer (service pages)
Contact us column (Perego logo, 2 emails, 2 phones, blurb, social icons: Instagram/Facebook/LinkedIn/YouTube/WhatsApp) · Contact form (Full name, E-mail, Your message, Send) · Join us (Full name, Portfolio/website link, CV upload, Apply now).

Contacts: `mostafa.emam3313@gmail.com`, `yehemam2@gmail.com`, `+996 56 293 2759`, `+20 111 54 855 72`.

## Motion
Hero slider + fade-up text; scroll fade-up reveals (IntersectionObserver); card/tab lift + magenta glow on hover; portfolio play-button scale on hover; staggered client-icon animation; drifting/glowing prism + wavy-line backgrounds. CSS-driven where possible; one small JS file for slider + reveals.
